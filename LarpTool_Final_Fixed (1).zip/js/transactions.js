// LarpBlox - Inventory and History Injection

function handleInventoryInjection() {
    const isInventory = window.location.href.includes('/inventory');
    const isAvatar = window.location.href.includes('/my/avatar');
    if (!isInventory && !isAvatar) return;

    const gridSelectors = [
        '.avatar-cards', '[data-testid="category-items"]', '.item-cards-stackable',
        '.item-list', '#assets-items ul', '.items-list', '.item-card-list',
        '.avatar-editor-avatar-card-grid', '.asset-cards', '.card-list', '.hlist'
    ];

    let grid = null;
    for (const sel of gridSelectors) {
        grid = document.querySelector(sel);
        if (grid) break;
    }

    if (grid) {
        // Efficiently deduplicate items by assetId (O(n))
        // We want to show only one card per unique asset.
        // If one of the copies is equipped, we prefer showing that version.
        const itemsToRenderMap = new Map();
        state.inventory.forEach(item => {
            const assetKey = (item.assetId && item.assetId !== "") ? String(item.assetId) : item.id;
            const isEquipped = (state.equipped || []).includes(item.id);
            if (!itemsToRenderMap.has(assetKey) || isEquipped) {
                itemsToRenderMap.set(assetKey, item);
            }
        });

        // Remove any simulated cards that are no longer the 'representative' for their asset
        // This handles cases where you buy a second copy or equip a different copy of the same item.
        const activeIds = new Set(Array.from(itemsToRenderMap.values()).map(i => i.id));
        grid.querySelectorAll('[data-sim-id]').forEach(el => {
            if (!activeIds.has(el.dataset.simId)) {
                el.remove();
            }
        });

        const injectedIds = new Set(Array.from(grid.querySelectorAll('[data-sim-id]')).map(el => el.dataset.simId));

        Array.from(itemsToRenderMap.values()).forEach(item => {
            if (injectedIds.has(item.id)) return;

            const isEquipped = (state.equipped || []).includes(item.id);
            const showEquipped = isAvatar && isEquipped;
            const wrapperTag = 'li';
            const wrapperClass = isAvatar ? 'avatar-card item-card' : 'list-item item-card';

            const checkBadge = showEquipped ? `
                <div class="item-card-equipped" data-item-status="equipped">
                    <div class="item-card-equipped-label"></div>
                    <span class="icon-check-selection"></span>
                </div>
            ` : '';

            let limitedBadge = '';
            if (item.limitedStatus === 'limited_u') limitedBadge = `<span class="restriction-icon icon-limited-unique-label"></span>`;
            else if (item.limitedStatus === 'limited') limitedBadge = `<span class="restriction-icon icon-limited-label"></span>`;

            // Status text for inventory page
            let statusHtml = '';
            if (isInventory) {
                const creatorText = item.creator || 'Roblox';
                statusHtml = `
                    <div class="item-card-creator">By&nbsp;<span class="text-name">${creatorText}</span></div>
                    <div class="item-card-price">
                        ${item.price > 0 ? `<span class="icon-robux-16x16"></span><span>${item.price.toLocaleString()}</span>` : '<span class="text-label">Offsale</span>'}
                    </div>
                `;
            }

            const itemPageUrl = item.assetId ? `/catalog/${item.assetId}/` : '#';

            const itemHtml = `
                <${wrapperTag} class="${wrapperClass}${showEquipped ? ' larp-equipped' : ''}" data-sim-id="${item.id}">
                    <div class="item-card-container">
                        <a href="${itemPageUrl}" class="item-card-link">
                            <div class="item-card-thumb-container">
                                ${checkBadge}
                                <div class="item-card-thumb-wrapper">
                                    <div class="thumbnail-2d-container">
                                        <img src="${item.image || ''}">
                                    </div>
                                    ${limitedBadge}
                                </div>
                            </div>
                            <div class="item-card-details">
                                <div class="item-card-name" title="${item.name}">${item.name}</div>
                                ${statusHtml}
                            </div>
                        </a>
                    </div>
                </${wrapperTag}>
            `.replace(/>\s+</g, '><').trim();

            grid.insertAdjacentHTML('afterbegin', itemHtml);

            const el = grid.querySelector(`[data-sim-id="${item.id}"]`);
            el.addEventListener('click', (e) => {
                if (!isAvatar) return; // Let default navigation happen on inventory page

                e.preventDefault();
                const currentEquipped = state.equipped || [];
                if (currentEquipped.includes(item.id)) {
                    state.equipped = currentEquipped.filter(id => id !== item.id);
                    el.classList.remove('larp-equipped');
                    const badge = el.querySelector('.item-card-equipped');
                    if (badge) badge.remove();
                } else {
                    state.equipped = [...currentEquipped, item.id];
                    el.classList.add('larp-equipped');
                    if (!el.querySelector('.item-card-equipped')) {
                        const thumbLink = el.querySelector('.item-card-thumb-container');
                        thumbLink.insertAdjacentHTML('afterbegin', `
                            <div class="item-card-equipped" data-item-status="equipped">
                                <div class="item-card-equipped-label"></div>
                                <span class="icon-check-selection"></span>
                            </div>
                        `);
                    }
                }
                chrome.storage.local.set({ equipped: state.equipped }, () => {
                    // Force a fresh render by clearing the combo key
                    window._larpComboKey = null;
                    handleAvatarLarping();
                });
            });

            if ((!item.image || item.image === "") && item.assetId) {
                const fixThumbnail = async () => {
                    try {
                        let thumbUrl = "";
                        const assetRes = await fetch(`https://thumbnails.roblox.com/v1/assets?assetIds=${item.assetId}&size=150x150&format=Png&isCircular=false`);
                        const assetData = await assetRes.json();
                        thumbUrl = assetData?.data?.[0]?.imageUrl;

                        if (!thumbUrl || thumbUrl.includes('placeholder') || thumbUrl.includes('empty')) {
                            const bundleRes = await fetch(`https://thumbnails.roblox.com/v1/bundles/thumbnails?bundleIds=${item.assetId}&size=150x150&format=Png&isCircular=false`);
                            const bundleData = await bundleRes.json();
                            thumbUrl = bundleData?.data?.[0]?.imageUrl;
                        }

                        if (thumbUrl && !thumbUrl.includes('pending')) {
                            item.image = thumbUrl;
                            const targetEl = grid.querySelector(`[data-sim-id="${item.id}"] img`);
                            if (targetEl) targetEl.src = thumbUrl;
                            chrome.storage.local.set({ inventory: state.inventory });
                        } else {
                            const targetEl = grid.querySelector(`[data-sim-id="${item.id}"] img`);
                            if (targetEl && targetEl.src === "") targetEl.src = ROBLOX_LOGO_URL;
                        }
                    } catch (e) {
                        console.error("[LarpBlox] Repair failed for", item.name, e);
                    }
                };
                fixThumbnail();
            } else if (!item.image) {
                const targetEl = grid.querySelector(`[data-sim-id="${item.id}"] img`);
                if (targetEl) targetEl.src = ROBLOX_LOGO_URL;
            }
        });
    }
}

function handleHistoryInjection() {
    if (!window.location.href.includes('/transactions')) {
        document.querySelectorAll('[data-sim-history]').forEach(r => r.remove());
        return;
    }
    if (state.history.length === 0) return;

    let isPurchasesTab = false;
    if (window.location.href.includes('type=Purchases')) isPurchasesTab = true;

    document.querySelectorAll('.rbx-selection-label, select').forEach(d => {
        const text = (d.value || d.textContent || '').trim().toLowerCase();
        if (text.includes('purchases') || text.includes('summary') ||
            text.includes('sales') || text.includes('incoming') || text.includes('trade')) {
            if (text.includes('purchases')) isPurchasesTab = true;
        }
    });

    if (!isPurchasesTab) {
        document.querySelectorAll('[data-sim-history]').forEach(r => r.remove());
        return;
    }

    let tbody = null;
    document.querySelectorAll('tbody').forEach(el => {
        if (!el.closest('[data-sim-history]') && el.offsetParent !== null && !tbody) {
            tbody = el;
        }
    });
    if (!tbody) return;

    const existingIds = new Set(Array.from(tbody.querySelectorAll('[data-sim-history]')).map(r => r.dataset.simHistory));
    const allPresent = state.history.every(item => {
        const id = btoa(encodeURIComponent(item.name + item.date)).substr(0, 20);
        return existingIds.has(id);
    });
    if (allPresent && existingIds.size === state.history.length) return;

    tbody.querySelectorAll('[data-sim-history]').forEach(r => r.remove());
    const fragment = document.createDocumentFragment();
    [...state.history].reverse().forEach((item) => {
        try {
            const dateObj = new Date(item.date);
            const dateStr = dateObj.toLocaleDateString('en-US', { month: '2-digit', day: '2-digit', year: '2-digit' });
            const timeStr = dateObj.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', hour12: true });
            const historyId = btoa(encodeURIComponent(item.name + item.date)).substr(0, 20);

            const row = document.createElement('tr');
            row.className = 'vlist-row';
            row.setAttribute('data-sim-history', historyId);
            row.innerHTML = `
                <td class="date">
                    <div>${dateStr}</div>
                    <div>${timeStr}</div>
                </td>
                <td class="user">
                    <div class="avatar-card">
                        <div class="avatar avatar-headshot-xs group-icon">
                            <a class="avatar-card-link" href="#">
                                <span class="thumbnail-2d-container">
                                    <img class="" src="${ROBLOX_LOGO_URL}" alt="" title="">
                                </span>
                            </a>
                        </div>
                        <div class="avatar-card-caption">
                            <a class="avatar-card-name text-name text-overflow" href="#">Roblox</a>
                        </div>
                    </div>
                </td>
                <td class="item">
                    <div class="item-format item-sale-format">
                        <span class="item-card-image">
                            <span class="thumbnail-2d-container">
                                <img class="" src="${item.image || ROBLOX_LOGO_URL}" alt="" title="${item.name}">
                            </span>
                        </span>
                        <div class="item-description">
                            <div><span>Purchased <a class="text-link text-overflow" href="#">${item.name}</a></span></div>
                        </div>
                    </div>
                </td>
                <td class="amount icon-robux-container">
                    <span>-</span><span class="icon-robux-16x16"></span><span class="">${item.price.toLocaleString()}</span>
                </td>
            `;
            fragment.appendChild(row);
        } catch (e) {
            console.warn('[LarpBlox] History row build error:', e);
        }
    });

    let insertAfter = null;
    const allRows = Array.from(tbody.querySelectorAll(':scope > tr'));
    for (const tr of allRows) {
        if (tr.dataset.simHistory) continue;
        const hasHeaders = tr.querySelector('th') !== null;
        const text = tr.textContent.trim().toLowerCase();
        const isHeaderRow = hasHeaders || (text.includes('date') && text.includes('source') && text.includes('amount'));
        if (isHeaderRow) { insertAfter = tr; break; }
    }
    const referenceNode = insertAfter ? insertAfter.nextSibling : (allRows[0] ? allRows[0].nextSibling : null);
    tbody.insertBefore(fragment, referenceNode);
}

function handleSummaryInjection() {
    if (!window.location.href.includes('/transactions')) return;
    let isSummaryTab = false;
    document.querySelectorAll('.rbx-selection-label, select').forEach(d => {
        const text = (d.value || d.textContent || '').trim().toLowerCase();
        if (text.includes('summary')) isSummaryTab = true;
    });
    if (!isSummaryTab) return;

    const totalLarpSpent = state.history.reduce((sum, item) => sum + (item.price || 0), 0);
    const originalBalance = state.setFakeRobux || (state.fakeRobux + totalLarpSpent);
    const formattedIncomingTotal = formatAmount(originalBalance, false);
    const formattedSpent = formatAmount(totalLarpSpent, false);

    const patchTextNode = (container, newText) => {
        if (!container) return false;
        try {
            const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null, false);
            let node;
            while ((node = walker.nextNode())) {
                const clean = node.nodeValue.replace(/,/g, '').trim();
                if (clean && /^\d+$/.test(clean)) {
                    if (node.nodeValue !== newText) node.nodeValue = newText;
                    return true;
                }
            }
        } catch (e) { }
        return false;
    };

    requestAnimationFrame(() => {
        try {
            let inIncoming = false;
            let inOutgoing = false;
            document.querySelectorAll('tr').forEach(row => {
                if (row.dataset.simHistory) return;
                const tds = row.querySelectorAll('td');
                const rowText = row.textContent.trim().toLowerCase();
                if (rowText.includes('incoming robux')) { inIncoming = true; inOutgoing = false; return; }
                if (rowText.includes('outgoing robux')) { inOutgoing = true; inIncoming = false; return; }
                if (tds.length < 2) return;
                const label = tds[0].textContent.trim().toLowerCase();
                const amountTd = tds[tds.length - 1];
                if (inIncoming && label === 'total') patchTextNode(amountTd, formattedIncomingTotal);
                if (inOutgoing && (label === 'purchases' || label === 'total')) patchTextNode(amountTd, formattedSpent);
            });
        } catch (e) { }
    });
}
