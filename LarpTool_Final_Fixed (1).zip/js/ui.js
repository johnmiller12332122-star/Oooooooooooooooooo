// LarpBlox - UI Update Logic

function updateRobuxElements() {
    try {
        const isTransactionsPage = window.location.href.includes('/transactions');
        const navSelectors = [
            '#nav-robux-amount',
            '.rbx-menu-item-label #nav-robux-amount',
            '#nav-robux-amount span'
        ];
        const fullSelectors = [
            '.robux-balance',
            '.amount.icon-robux-container',
            '.balance-label',
            '[data-testid="robux-amount"]',
            '.robux-text'
        ];

        const formattedFull = formatAmount(state.fakeRobux, false);
        const formattedAbbr = formatAmount(state.fakeRobux, true);

        // Update Nav Amounts (Abbreviated)
        navSelectors.forEach(selector => {
            try {
                document.querySelectorAll(selector).forEach(el => {
                    if (el.textContent.trim() !== formattedAbbr) el.textContent = formattedAbbr;
                });
            } catch (e) { }
        });

        // Update Page Amounts (Full) — skip on transactions page
        if (!isTransactionsPage) {
            fullSelectors.forEach(selector => {
                try {
                    document.querySelectorAll(selector).forEach(el => {
                        if (el.closest('.vlist-row') || el.closest('tr') || el.closest('.table-body') || el.closest('.item-card') || el.closest('.item-card-container')) return;
                        if (el.textContent.trim() !== formattedFull) {
                            el.textContent = formattedFull;
                        }
                    });
                } catch (e) { }
            });
            return;
        }

        // Transactions page: safe text-node balance spoofing
        const oldBadge = document.getElementById('larp-tx-balance-badge');
        if (oldBadge) oldBadge.remove();

        const patchNumericTextNode = (container, newText) => {
            if (!container) return false;
            try {
                const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT, null, false);
                let node;
                while ((node = walker.nextNode())) {
                    if (node.parentElement && node.parentElement.closest('[id^="larp-"]')) continue;
                    const clean = node.nodeValue.replace(/,/g, '').trim();
                    if (clean && /^\d+$/.test(clean)) {
                        if (node.nodeValue !== newText) node.nodeValue = newText;
                        return true;
                    }
                }
            } catch (e) { }
            return false;
        };

        requestAnimationFrame(() => {
            try {
                const balanceCandidates = document.querySelectorAll(
                    '.balance-label, .my-balance, [class*="balance"], [class*="Balance"]'
                );
                balanceCandidates.forEach(el => {
                    if (el.closest('tr') || el.closest('.vlist-row') || el.closest('[id^="larp-"]')) return;
                    const rect = el.getBoundingClientRect();
                    if (rect.top > 300) return;
                    patchNumericTextNode(el, formattedFull);
                });
            } catch (e) { }
        });

    } catch (e) {
        console.warn('[LarpBlox] updateRobuxElements error:', e);
    }
}

function handleProfileSpoofing() {
    const isProfilePage = window.location.href.includes('/users/') && window.location.href.includes('/profile');
    let isMyProfile = false;

    if (isProfilePage) {
        const metaTag = document.querySelector('meta[name="user-data"]');
        if (metaTag) {
            const myUserId = metaTag.getAttribute('data-userid');
            const match = window.location.href.match(/\/users\/(\d+)/);
            if (match && myUserId && match[1] === myUserId) {
                isMyProfile = true;
            }
        }
        if (!isMyProfile && document.body) {
            const btns = Array.from(document.querySelectorAll('a, button, span'));
            if (btns.some(el => el.textContent.trim() === 'Edit Profile' || el.textContent.trim() === 'Edit Avatar')) {
                isMyProfile = true;
            }
        }
    }

    // 1. Larp Display Name (Only Profile Header and Top Nav)
    if (state.larpDisplayName) {
        // Main profile header - ONLY on my profile
        if (isMyProfile) {
            const mainDisplayName = document.querySelector('#profile-header-title-container-name, .profile-header .header-title h2');
            if (mainDisplayName && mainDisplayName.textContent.trim() !== state.larpDisplayName) {
                mainDisplayName.textContent = state.larpDisplayName;
            }
        }

        // Sidebar Top Profile Name - Always spoof as it represents the logged-in user
        const sidebarTopProfile = document.querySelector('.rbx-left-col .rbx-user-link .text-truncate-end, .rbx-left-col .rbx-user-item .text-truncate-end, .rbx-left-col li:first-child .text-truncate-end, .flex.gap-xsmall.min-width-0 .text-truncate-end.text-no-wrap');
        if (sidebarTopProfile && sidebarTopProfile.textContent.trim() !== state.larpDisplayName) {
            sidebarTopProfile.textContent = state.larpDisplayName;
        }

        // Top nav mini profile (left and right sides) - Always spoof
        const headerElements = document.querySelectorAll('.rbx-header .text-truncate-end.text-no-wrap, .rbx-header .text-overflow, .rbx-header .age-bracket-label-username, .rbx-header .navbar-right .text-overflow');
        headerElements.forEach(el => {
            if (el.closest('.rbx-header') || el.closest('.navbar-right')) {
                if (el.textContent.trim() !== state.larpDisplayName) {
                    el.textContent = state.larpDisplayName;
                }
            }
        });
    }

    // 2. Larp Username (@name) (Only Profile Header - ONLY on my profile)
    if (state.larpUsername && isMyProfile) {
        const cleanUser = state.larpUsername.startsWith('@') ? state.larpUsername : '@' + state.larpUsername;
        const mainUsername = document.querySelector('.stylistic-alts-username, .profile-header .header-names .header-caption');

        if (mainUsername) {
            const text = mainUsername.textContent.trim();
            if (text.startsWith('@') && text !== cleanUser) {
                mainUsername.textContent = cleanUser;
            }
        }
    }

    // 3. Verified Badge (Only Profile Header - ONLY on my profile)
    if (state.isVerified && isMyProfile) {
        const mainDisplay = document.querySelector('#profile-header-title-container-name, .profile-header .header-title h2');
        if (mainDisplay) {
            const container = mainDisplay.parentElement;
            if (container && !container.querySelector('.larp-verified-badge')) {
                const badge = document.createElement('span');
                badge.className = 'larp-verified-badge';
                badge.style.display = 'inline-flex';
                badge.style.alignItems = 'center';
                badge.style.marginLeft = '4px';
                badge.style.verticalAlign = 'middle';
                badge.title = 'Verified';
                badge.innerHTML = `
                    <svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 32 32" fill="none" style="margin-top: 1px;">
                        <path d="M10.1641 3.06852C9.09906 2.78315 8.00434 3.41518 7.71897 4.48022L3.06852 21.8359C2.78315 22.9009 3.41518 23.9957 4.48022 24.281L21.8359 28.9315C22.9009 29.2169 23.9957 28.5848 24.281 27.5198L28.9315 10.1641C29.2169 9.09906 28.5848 8.00434 27.5198 7.71897L10.1641 3.06852ZM21.7071 12.2929C22.0976 12.6834 22.0976 13.3166 21.7071 13.7071L14.7071 20.7071C14.3166 21.0976 13.6834 21.0976 13.2929 20.7071L10.2929 17.7071C9.90237 17.3166 9.90237 16.6834 10.2929 16.2929C10.6834 15.9024 11.3166 15.9024 11.7071 16.2929L14 18.5858L20.2929 12.2929C20.6834 11.9024 21.3166 11.9024 21.7071 12.2929Z" fill="#335FFF"/>
                    </svg>
                `;
                mainDisplay.after(badge);
                console.log('[LarpBlox] Injected Actual Modern Verified Badge');
            }
        }
    }
}

let updateTimeout;
function throttledUpdate() {
    if (updateTimeout) return;
    updateTimeout = setTimeout(() => {
        updateRobuxElements();
        handleBuyButton();

        if (window.location.href.includes('/inventory') || window.location.href.includes('/my/avatar')) {
            handleInventoryInjection();
        }
        if (window.location.href.includes('/transactions')) {
            handleHistoryInjection();
        }

        handleProfileSpoofing();

        updateTimeout = null;
    }, 500);
}
