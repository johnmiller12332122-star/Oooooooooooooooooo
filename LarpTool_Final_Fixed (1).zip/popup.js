document.addEventListener('DOMContentLoaded', () => {
    const robuxInput = document.getElementById('robux-amount');
    const larpDisplayNameInput = document.getElementById('larp-display-name');
    const larpUsernameInput = document.getElementById('larp-username');
    const isVerifiedInput = document.getElementById('is-verified');

    const saveBtn = document.getElementById('save-btn');
    const resetBtn = document.getElementById('reset-btn');
    const status = document.getElementById('status');
    const addItemIdInput = document.getElementById('manual-item-id');
    const addItemBtn = document.getElementById('add-item-btn');

    const authContent = document.getElementById('auth-content');
    const mainContent = document.getElementById('main-content');
    const authBtn = document.getElementById('auth-btn');
    const licenseKeyInput = document.getElementById('license-key');
    const authErrorMsg = document.getElementById('auth-error-msg');
    const togglePassword = document.getElementById('toggle-password');

    if (togglePassword) {
        togglePassword.addEventListener('click', () => {
            const type = licenseKeyInput.getAttribute('type') === 'password' ? 'text' : 'password';
            licenseKeyInput.setAttribute('type', type);
            togglePassword.classList.toggle('active');
        });
    }

    const uiModeSelect = document.getElementById('ui-mode');

    // Load current state
    chrome.storage.local.get(['fakeRobux', 'isAuthenticated', 'uiMode', 'larpDisplayName', 'larpUsername', 'isVerified'], (result) => {
        if (result.isAuthenticated) {
            authContent.style.display = 'none';
            mainContent.style.display = 'block';
        }

        if (result.fakeRobux !== undefined) {
            robuxInput.value = result.fakeRobux;
        }

        if (uiModeSelect) {
            uiModeSelect.value = (result.uiMode && ['auto', 'light', 'dark'].includes(result.uiMode)) ? result.uiMode : 'auto';
        }
        if (result.larpDisplayName) larpDisplayNameInput.value = result.larpDisplayName;
        if (result.larpUsername) larpUsernameInput.value = result.larpUsername;
        if (result.isVerified) isVerifiedInput.checked = result.isVerified;
    });

    // Handle Authentication
    authBtn.addEventListener('click', async () => {
        const key = licenseKeyInput.value.trim();
        authErrorMsg.style.display = 'none';

        if (!key) {
            authErrorMsg.textContent = "Please enter a license key.";
            authErrorMsg.style.display = 'block';
            return;
        }

        const originalContent = authBtn.innerHTML;
        authBtn.innerHTML = '<span class="loader"></span>';
        authBtn.style.pointerEvents = 'none';

        const GATEKEEPER_URL = "https://xbqqmafqcxeyijaiiwrm.supabase.co/functions/v1/quick-endpoint";

        try {
            const res = await fetch(GATEKEEPER_URL, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ key: key })
            });

            const data = await res.json();

            if (data.status === "success") {
                chrome.storage.local.set({ isAuthenticated: true }, () => {
                    authContent.style.transform = 'translateY(-10px)';
                    authContent.style.opacity = '0';
                    setTimeout(() => {
                        authContent.style.display = 'none';
                        mainContent.style.display = 'flex';
                        mainContent.style.flexDirection = 'column';
                        mainContent.style.opacity = '0';
                        mainContent.style.transform = 'translateY(10px)';
                        setTimeout(() => {
                            mainContent.style.opacity = '1';
                            mainContent.style.transform = 'translateY(0)';
                        }, 50);
                    }, 300);
                });
            } else {
                authErrorMsg.textContent = data.message || "Invalid license key!";
                authErrorMsg.style.display = 'block';
            }
        } catch (error) {
            authErrorMsg.textContent = "Server Connection failed.";
            authErrorMsg.style.display = 'block';
            console.error("Auth Error:", error);
        }

        authBtn.innerHTML = originalContent;
        authBtn.style.pointerEvents = 'auto';
    });

    saveBtn.addEventListener('click', () => {
        const amount = parseInt(robuxInput.value);
        const uiModeValue = (uiModeSelect && uiModeSelect.value) ? uiModeSelect.value : 'auto';

        if (isNaN(amount) && amount !== undefined) return;

        saveBtn.classList.add('loading');
        const originalText = saveBtn.querySelector('span').textContent;
        saveBtn.querySelector('span').textContent = 'Saving...';

        chrome.storage.local.set({
            fakeRobux: amount,
            setFakeRobux: amount,
            uiMode: uiModeValue,
            larpDisplayName: larpDisplayNameInput.value.trim(),
            larpUsername: larpUsernameInput.value.trim(),
            isVerified: isVerifiedInput.checked
        }, () => {
            setTimeout(() => {
                saveBtn.classList.remove('loading');
                saveBtn.querySelector('span').textContent = originalText;
                showStatus('Success!');
            }, 600);
        });
    });

    addItemBtn.addEventListener('click', async () => {
        const assetId = addItemIdInput.value.trim();
        if (!assetId) return;

        showStatus('Adding...');
        addItemBtn.disabled = true;
        addItemBtn.style.opacity = '0.5';

        try {
            // First try as normal asset
            let detailRes = await fetch(`https://economy.roblox.com/v2/assets/${assetId}/details`);

            // If it fails, try as a bundle
            if (!detailRes.ok) {
                const bundleRes = await fetch(`https://catalog.roblox.com/v1/bundles/${assetId}/details`);
                if (bundleRes.ok) {
                    showStatus('Adding Bundle...');
                    const bundleData = await bundleRes.json();
                    if (bundleData.items && bundleData.items.length > 0) {
                        const assets = bundleData.items.filter(item => item.type === "Asset");
                        if (assets.length > 0) {
                            const assetIdsStr = assets.map(a => a.id).join(',');
                            const thumbRes = await fetch(`https://thumbnails.roblox.com/v1/assets?assetIds=${assetIdsStr}&returnPolicy=PlaceHolder&size=420x420&format=Png&isCircular=false`);
                            let thumbsMap = {};
                            if (thumbRes.ok) {
                                const thumbData = await thumbRes.json();
                                (thumbData.data || []).forEach(t => { thumbsMap[t.targetId] = t.imageUrl; });
                            }

                            chrome.storage.local.get(['inventory'], (result) => {
                                const inventory = result.inventory || [];
                                for (const item of assets) {
                                    inventory.push({
                                        name: item.name,
                                        image: thumbsMap[item.id] || "",
                                        creator: bundleData.creator?.name || "Roblox",
                                        date: new Date().toISOString(),
                                        id: Math.random().toString(36).substr(2, 9),
                                        assetId: item.id.toString(),
                                        limitedStatus: null
                                    });
                                }
                                chrome.storage.local.set({ inventory }, () => {
                                    addItemIdInput.value = '';
                                    showStatus('Bundle Added!');
                                    addItemBtn.disabled = false;
                                    addItemBtn.style.opacity = '1';
                                });
                            });
                            return; // Stop here for bundles
                        }
                    }
                }
                throw new Error('Invalid Asset or Bundle ID');
            }

            const data = await detailRes.json();

            // Fetch thumbnail
            const thumbRes = await fetch(`https://thumbnails.roblox.com/v1/assets?assetIds=${assetId}&returnPolicy=PlaceHolder&size=420x420&format=Png&isCircular=false`);
            let imageUrl = '';
            if (thumbRes.ok) {
                const thumbData = await thumbRes.json();
                imageUrl = thumbData.data?.[0]?.imageUrl || '';
            }

            // Detect limited status
            let limitedStatus = null;
            if (data.IsLimitedUnique) limitedStatus = 'limited_u';
            else if (data.IsLimited) limitedStatus = 'limited';

            // Save to storage
            chrome.storage.local.get(['inventory'], (result) => {
                const inventory = result.inventory || [];
                inventory.push({
                    name: data.Name || data.name || "Roblox Item",
                    image: imageUrl,
                    creator: data.Creator?.Name || "Roblox",
                    date: new Date().toISOString(),
                    id: Math.random().toString(36).substr(2, 9),
                    assetId: assetId,
                    limitedStatus: limitedStatus
                });
                chrome.storage.local.set({ inventory }, () => {
                    addItemIdInput.value = '';
                    showStatus('Item Added!');
                    addItemBtn.disabled = false;
                    addItemBtn.style.opacity = '1';
                });
            });

        } catch (e) {
            showStatus('Invalid ID');
            console.error(e);
            addItemBtn.disabled = false;
            addItemBtn.style.opacity = '1';
        }
    });

    resetBtn.addEventListener('click', () => {
        if (confirm('Are you sure you want to reset all simulated data?')) {
            chrome.storage.local.remove(['fakeRobux', 'inventory', 'history', 'equipped', 'larpDisplayName', 'larpUsername', 'isVerified'], () => {
                robuxInput.value = 10000000;
                larpDisplayNameInput.value = '';
                larpUsernameInput.value = '';
                isVerifiedInput.checked = false;
                showStatus('Reset complete');
            });
        }
    });


    function showStatus(text) {
        const originalText = status.textContent;
        status.textContent = text;
        const statusEl = document.querySelector('.status-indicator');
        statusEl.classList.add('active');

        setTimeout(() => {
            status.textContent = originalText;
            statusEl.classList.remove('active');
        }, 2500);
    }
});
