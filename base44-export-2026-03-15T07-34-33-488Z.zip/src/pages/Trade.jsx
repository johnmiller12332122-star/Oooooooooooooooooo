const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useEffect } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Navbar from '../components/navbar/Navbar';
import { Button } from '@/components/ui/button';
import { Loader2, ArrowRightLeft, Plus, Check, X, ChevronDown, Package, AtSign, DollarSign } from 'lucide-react';
import { toast } from 'sonner';
import CreateTradeModal from '../components/trade/CreateTradeModal';
import TradeCard from '../components/trade/TradeCard';

export default function Trade() {
  const [currentUser, setCurrentUser] = useState(null);
  const [showCreate, setShowCreate] = useState(false);
  const [tab, setTab] = useState('incoming');
  const queryClient = useQueryClient();

  React.useEffect(() => {
    db.auth.me().then(setCurrentUser);
  }, []);

  const { data: profiles = {} } = useQuery({
    queryKey: ['profiles'],
    queryFn: async () => {
      const list = await db.entities.UserProfile.list();
      return Object.fromEntries(list.map(p => [p.email, p]));
    },
    enabled: !!currentUser,
  });

  const { data: trades = [], isLoading } = useQuery({
    queryKey: ['trades', currentUser?.email],
    queryFn: () => db.entities.TradeOffer.list('-created_date', 100),
    enabled: !!currentUser,
  });

  const { data: myNFTs = [] } = useQuery({
    queryKey: ['my-nfts', currentUser?.email],
    queryFn: () => db.entities.NFTInventory.filter({ owner_email: currentUser.email }),
    enabled: !!currentUser,
  });

  const { data: myUsernames = [] } = useQuery({
    queryKey: ['my-usernames', currentUser?.email],
    queryFn: () => db.entities.CollectibleUsername.filter({ owner_email: currentUser.email }),
    enabled: !!currentUser,
  });

  const updateTrade = useMutation({
    mutationFn: async ({ id, status, trade }) => {
      await db.entities.TradeOffer.update(id, { status });
      if (status === 'accepted') {
        // Transfer NFT or username
        if (trade.offer_item_type === 'nft' && trade.offer_nft_id) {
          await db.entities.NFTInventory.update(trade.offer_nft_id, { owner_email: trade.to_email });
        }
        if (trade.offer_item_type === 'username' && trade.offer_username) {
          const uns = await db.entities.CollectibleUsername.filter({ username: trade.offer_username });
          if (uns[0]) await db.entities.CollectibleUsername.update(uns[0].id, { owner_email: trade.to_email });
        }
        if (trade.request_item_type === 'nft' && trade.request_nft_id) {
          await db.entities.NFTInventory.update(trade.request_nft_id, { owner_email: trade.from_email });
        }
        if (trade.request_item_type === 'username' && trade.request_username) {
          const uns = await db.entities.CollectibleUsername.filter({ username: trade.request_username });
          if (uns[0]) await db.entities.CollectibleUsername.update(uns[0].id, { owner_email: trade.from_email });
        }
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['trades'] });
      queryClient.invalidateQueries({ queryKey: ['my-nfts'] });
      queryClient.invalidateQueries({ queryKey: ['my-usernames'] });
    },
  });

  const cancelTrade = useMutation({
    mutationFn: (id) => db.entities.TradeOffer.update(id, { status: 'cancelled' }),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['trades'] }),
  });

  if (!currentUser) return (
    <div className="h-screen bg-slate-950 flex items-center justify-center">
      <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
    </div>
  );

  const incoming = trades.filter(t => t.to_email === currentUser.email && t.status === 'pending');
  const outgoing = trades.filter(t => t.from_email === currentUser.email && t.status === 'pending');
  const history = trades.filter(t =>
    (t.from_email === currentUser.email || t.to_email === currentUser.email) &&
    t.status !== 'pending'
  );

  const visibleTrades = tab === 'incoming' ? incoming : tab === 'outgoing' ? outgoing : history;

  return (
    <div className="min-h-screen bg-slate-950 pb-20 md:pb-0 md:pt-16">
      <Navbar />
      <div className="max-w-3xl mx-auto px-4 py-6">
        {/* Header */}
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-white flex items-center gap-2">
              <ArrowRightLeft className="w-6 h-6 text-blue-400" />
              Trading
            </h1>
            <p className="text-slate-400 text-sm mt-1">Swap NFTs & usernames peer-to-peer</p>
          </div>
          <Button onClick={() => setShowCreate(true)} className="bg-blue-600 hover:bg-blue-700">
            <Plus className="w-4 h-4 mr-1" /> New Trade
          </Button>
        </div>

        {/* Tabs */}
        <div className="flex gap-1 bg-slate-900 rounded-lg p-1 mb-6">
          {[
            { key: 'incoming', label: 'Incoming', count: incoming.length },
            { key: 'outgoing', label: 'Outgoing', count: outgoing.length },
            { key: 'history', label: 'History', count: history.length },
          ].map(t => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex-1 py-2 px-3 rounded-md text-sm font-medium transition-colors flex items-center justify-center gap-2 ${
                tab === t.key ? 'bg-slate-700 text-white' : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              {t.label}
              {t.count > 0 && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${tab === t.key ? 'bg-blue-500 text-white' : 'bg-slate-700 text-slate-300'}`}>
                  {t.count}
                </span>
              )}
            </button>
          ))}
        </div>

        {/* Trade list */}
        {isLoading ? (
          <div className="flex justify-center py-16"><Loader2 className="w-6 h-6 animate-spin text-slate-500" /></div>
        ) : visibleTrades.length === 0 ? (
          <div className="text-center py-16 text-slate-500">
            <ArrowRightLeft className="w-10 h-10 mx-auto mb-3 opacity-30" />
            <p className="text-sm">No trades here yet.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {visibleTrades.map(trade => (
              <TradeCard
                key={trade.id}
                trade={trade}
                currentUserEmail={currentUser.email}
                profiles={profiles}
                onAccept={() => {
                  updateTrade.mutate({ id: trade.id, status: 'accepted', trade });
                  toast.success('Trade accepted!');
                }}
                onDecline={() => {
                  updateTrade.mutate({ id: trade.id, status: 'declined', trade });
                  toast.info('Trade declined.');
                }}
                onCancel={() => {
                  cancelTrade.mutate(trade.id);
                  toast.info('Trade cancelled.');
                }}
              />
            ))}
          </div>
        )}
      </div>

      {showCreate && (
        <CreateTradeModal
          currentUser={currentUser}
          profiles={profiles}
          myNFTs={myNFTs}
          myUsernames={myUsernames}
          onClose={() => setShowCreate(false)}
          onCreated={() => {
            queryClient.invalidateQueries({ queryKey: ['trades'] });
            setShowCreate(false);
            setTab('outgoing');
            toast.success('Trade offer sent!');
          }}
        />
      )}
    </div>
  );
}