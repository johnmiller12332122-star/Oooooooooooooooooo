const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useEffect } from 'react';

import { useQuery } from '@tanstack/react-query';
import Navbar from '../components/navbar/Navbar';
import Avatar from '../components/chat/Avatar';
import StatusDot from '../components/chat/StatusDot';
import NFTCard from '../components/chat/NFTCard';
import NFTDetailsModal from '../components/shop/NFTDetailsModal';
import UsernameDetailsModal from '../components/shop/UsernameDetailsModal';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ArrowLeft, AtSign, Calendar, Wallet, Shield, MessageSquare, Loader2, TrendingUp } from 'lucide-react';

import BadgeIcon from '../components/shared/BadgeIcon';
import { BADGE_CONFIG } from '../components/shared/badgeConfig';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import moment from 'moment';

export default function UserView() {
  const urlParams = new URLSearchParams(window.location.search);
  const username = urlParams.get('username');
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState(null);
  const [selectedNFT, setSelectedNFT] = useState(null);
  const [selectedUsername, setSelectedUsername] = useState(null);

  useEffect(() => {
    db.auth.me().then(setCurrentUser);
  }, []);

  const { data: profile, isLoading } = useQuery({
    queryKey: ['userProfile', username],
    queryFn: async () => {
      const list = await db.entities.UserProfile.filter({ username });
      return list[0] || null;
    },
    enabled: !!username,
  });

  const { data: userSocial = [] } = useQuery({
    queryKey: ['userSocial', profile?.email],
    queryFn: () => db.entities.SocialConnection.filter({ 
      user_email: profile.email,
      display_on_profile: true
    }),
    enabled: !!profile,
  });

  const { data: userUsernames = [] } = useQuery({
    queryKey: ['userUsernames', profile?.email],
    queryFn: async () => {
      const all = await db.entities.CollectibleUsername.filter({ owner_email: profile.email });
      return all.filter(u => u.visible_on_profile !== false);
    },
    enabled: !!profile,
  });

  const { data: userInventory = [] } = useQuery({
    queryKey: ['userInventory', profile?.email],
    queryFn: () => db.entities.NFTInventory.filter({ 
      owner_email: profile.email,
      visible_on_profile: true
    }),
    enabled: !!profile,
  });

  if (isLoading) {
    return (
      <div className="h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-400">
        <p className="text-lg mb-4">User not found</p>
        <Link to={createPageUrl('Home')}>
          <Button variant="outline" className="border-slate-700 text-slate-300">
            Go Back
          </Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20 md:pb-0 md:pt-20">
      <Navbar />
      {/* Header gradient */}
      <div className="h-32 bg-gradient-to-r from-blue-600/20 via-purple-600/20 to-pink-600/20 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-slate-950" />
        <div className="absolute top-4 left-4">
          <Link to={createPageUrl('Home')}>
            <Button variant="ghost" size="icon" className="text-slate-300 hover:text-white h-8 w-8">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>

      <div className="max-w-lg mx-auto px-4 -mt-16 pb-8">
        {/* Avatar */}
        <div className="flex flex-col items-center">
          <Avatar
            src={profile.profile_picture}
            name={profile.display_name || profile.email}
            status={profile.status}
            size="2xl"
          />
          <div className="flex items-center gap-2 mt-4 flex-wrap justify-center">
            <h1 className="text-2xl font-bold">{profile.display_name}</h1>
            {profile.badges?.filter(b => BADGE_CONFIG[b]?.inline).map(b => (
              <BadgeIcon key={b} badgeKey={b} cfg={BADGE_CONFIG[b]} size={6} />
            ))}
            {userUsernames.length > 0 && (
              <span className="text-sm font-bold px-2 py-0.5 rounded"
                style={{ color: '#FFD700', textShadow: '0 0 10px #FFD700, 0 0 20px #FFA500' }}>
                OWNER
              </span>
            )}
          </div>
          {profile.username && (
            <div className="flex items-center gap-1 mt-1">
              <AtSign className="w-3.5 h-3.5 text-blue-400" />
              <span className="text-blue-400">{profile.username}</span>
            </div>
          )}
          {userUsernames.length > 0 && (
            <div className="flex flex-wrap items-center justify-center gap-1 mt-1.5">
              <span className="text-xs text-slate-500">also known as</span>
              {userUsernames.map(u => (
                <button
                  key={u.id}
                  onClick={() => setSelectedUsername({ username: u, owner: profile })}
                  className="text-xs text-blue-400 hover:underline"
                >
                  @{u.username}
                </button>
              ))}
            </div>
          )}
          <div className="flex items-center gap-1.5 mt-2">
            <StatusDot status={profile.status || 'offline'} size="sm" />
            <span className="text-sm text-slate-400 capitalize">{profile.status || 'offline'}</span>
          </div>
        </div>

        {/* Badges */}
        {profile.badges?.length > 0 && (
          <div className="flex flex-wrap gap-2 justify-center mt-4">
            {profile.badges.map((badge) => (
              <BadgeIcon key={badge} badgeKey={badge} cfg={BADGE_CONFIG[badge]} size={8} />
            ))}
          </div>
        )}

        {/* Bio */}
        {profile.bio && (
          <p className="text-center text-slate-400 mt-4 text-sm italic">"{profile.bio}"</p>
        )}

        {/* Info */}
        <div className="mt-6 space-y-2">
          <div className="flex items-center gap-2 text-sm text-slate-500 justify-center">
            <Calendar className="w-4 h-4" />
            <span>Joined {moment(profile.created_date).format('MMMM YYYY')}</span>
          </div>
          {profile.wallet_address && (
            <div className="flex items-center gap-2 text-sm text-slate-500 justify-center">
              <Wallet className="w-4 h-4" />
              <span className="font-mono">{profile.wallet_address.slice(0, 8)}...{profile.wallet_address.slice(-6)}</span>
            </div>
          )}
        </div>

        {/* Message button */}
        {currentUser && currentUser.email !== profile.email && (
          <div className="mt-6 flex justify-center">
            <Button
              className="bg-blue-600 hover:bg-blue-500 px-8"
              onClick={() => navigate(createPageUrl('Home'))}
            >
              <MessageSquare className="w-4 h-4 mr-2" />
              Send Message
            </Button>
          </div>
        )}

        {/* Social Connections */}
        {userSocial.length > 0 && (
          <div className="mt-8">
            <h3 className="text-sm font-semibold text-slate-400 uppercase tracking-wider mb-4 text-center">
              Social Accounts
            </h3>
            <div className="space-y-2">
              {userSocial.map((conn) => (
                <div key={conn.id} className="bg-slate-900 border border-slate-800 rounded-lg p-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center capitalize">
                      {conn.platform[0]}
                    </div>
                    <div>
                      <div className="font-medium capitalize">{conn.platform}</div>
                      <div className="text-xs text-slate-500">@{conn.platform_username}</div>
                    </div>
                  </div>
                  {conn.show_stats && (
                    <div className="text-xs text-slate-500">
                      {conn.followers} followers
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Owned Usernames */}
        {userUsernames.length > 0 && (
          <div className="mt-8">
            <h3 className="text-base font-bold text-slate-200 mb-4 flex items-center gap-2">
              <AtSign className="w-5 h-5 text-blue-400" />
              Owned Usernames
            </h3>
            <div className="space-y-2">
              {userUsernames.map((u) => (
                <div
                  key={u.id}
                  onClick={() => setSelectedUsername({ username: u, owner: profile })}
                  className="bg-slate-900 border border-slate-800 rounded-lg p-4 flex items-center justify-between cursor-pointer hover:border-slate-700 transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center">
                      <AtSign className="w-5 h-5 text-blue-400" />
                    </div>
                    <span className="font-semibold text-lg">@{u.username}</span>
                  </div>
                  <span className="text-emerald-400 font-bold">${u.price_usd?.toFixed(2)}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* NFT Inventory */}
        {userInventory.length > 0 && (
          <div className="mt-8">
            <h3 className="text-base font-bold text-slate-200 mb-4 flex items-center gap-2">
              <Shield className="w-5 h-5 text-purple-400" />
              NFT Collection ({userInventory.length})
            </h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {userInventory.map((item) => (
                <div
                  key={item.id}
                  onClick={() => setSelectedNFT({ 
                    nft: { 
                      ...item, 
                      name: item.nft_name, 
                      image_url: item.nft_image 
                    }, 
                    owner: profile,
                    tokenId: item.token_id,
                    totalSupply: item.total_supply
                  })}
                  className="cursor-pointer bg-slate-900 rounded-lg overflow-hidden border border-slate-800 hover:border-slate-700 transition-colors"
                >
                  <div className="aspect-square bg-gradient-to-br from-purple-900/20 to-blue-900/20 flex items-center justify-center p-4">
                    {item.nft_image ? (
                      <img src={item.nft_image} alt={item.nft_name} className="w-full h-full object-contain" />
                    ) : (
                      <div className="text-4xl">🎨</div>
                    )}
                  </div>
                  <div className="p-3">
                    <div className="font-semibold text-sm">{item.nft_name}</div>
                    <div className="text-xs text-cyan-400">{item.collection}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      <NFTDetailsModal
        nft={selectedNFT?.nft}
        owner={selectedNFT?.owner}
        tokenId={selectedNFT?.tokenId}
        totalSupply={selectedNFT?.totalSupply}
        open={!!selectedNFT}
        onClose={() => setSelectedNFT(null)}
      />

      <UsernameDetailsModal
        username={selectedUsername?.username}
        owner={selectedUsername?.owner}
        open={!!selectedUsername}
        onClose={() => setSelectedUsername(null)}
      />
    </div>
  );
}