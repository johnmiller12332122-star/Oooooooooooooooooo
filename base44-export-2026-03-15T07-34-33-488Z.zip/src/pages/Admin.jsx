const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useEffect } from 'react';

import { useQuery, useQueryClient } from '@tanstack/react-query';
import Navbar from '../components/navbar/Navbar';
import Avatar from '../components/chat/Avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Search, Shield, Loader2, X, Plus } from 'lucide-react';
import { toast } from 'sonner';

const BADGE_CONFIG = {
  verified: { label: 'Verified', image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/d26f0d0a8_image.png' },
  bug_hunter: { label: 'Bug Hunter', image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/4d2e7f0ae_image.png' },
  bug_hunter_blue: { label: 'Bug Hunter II', image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/fdcd91746_image.png' },
  bug_hunter_gold: { label: 'Bug Hunter III', image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/282dd1530_image.png' },
  moderator: { label: 'Moderator', image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/29107cda0_image.png' },
  staff: { label: 'Staff', image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/c972ca94d_image.png' },
  og: { label: 'OG', image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/c227339e2_image.png' },
};

export default function Admin() {
  const [currentUser, setCurrentUser] = useState(null);
  const [search, setSearch] = useState('');
  const queryClient = useQueryClient();

  useEffect(() => {
    db.auth.me().then(setCurrentUser);
  }, []);

  const { data: profiles = [], isLoading } = useQuery({
    queryKey: ['allProfiles'],
    queryFn: () => db.entities.UserProfile.list(),
    enabled: !!currentUser,
  });

  const filtered = profiles.filter(p =>
    p.display_name?.toLowerCase().includes(search.toLowerCase()) ||
    p.email?.toLowerCase().includes(search.toLowerCase()) ||
    p.username?.toLowerCase().includes(search.toLowerCase())
  );

  const grantBadge = async (profile, badgeId) => {
    const badges = [...(profile.badges || [])];
    if (badges.includes(badgeId)) {
      toast.info('User already has this badge');
      return;
    }
    badges.push(badgeId);
    await db.entities.UserProfile.update(profile.id, { badges });
    queryClient.invalidateQueries({ queryKey: ['allProfiles'] });
    queryClient.invalidateQueries({ queryKey: ['profiles'] });
    toast.success(`Granted ${BADGE_CONFIG[badgeId].label} to ${profile.display_name || profile.email}`);
  };

  const revokeBadge = async (profile, badgeId) => {
    const badges = (profile.badges || []).filter(b => b !== badgeId);
    await db.entities.UserProfile.update(profile.id, { badges });
    queryClient.invalidateQueries({ queryKey: ['allProfiles'] });
    queryClient.invalidateQueries({ queryKey: ['profiles'] });
    toast.success(`Revoked badge from ${profile.display_name || profile.email}`);
  };

  if (!currentUser) return (
    <div className="h-screen bg-slate-950 flex items-center justify-center">
      <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
    </div>
  );

  if (currentUser.role !== 'admin') return (
    <div className="h-screen bg-slate-950 flex flex-col items-center justify-center text-slate-400 gap-4">
      <Shield className="w-12 h-12 text-red-500" />
      <p className="text-lg">Admin access required</p>
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20 md:pb-0 md:pt-20">
      <Navbar />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center gap-3 mb-8">
          <Shield className="w-7 h-7 text-purple-400" />
          <div>
            <h1 className="text-2xl font-bold">Admin Panel</h1>
            <p className="text-slate-400 text-sm">Manage user badges and profiles</p>
          </div>
        </div>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search users..."
            className="pl-10 bg-slate-900 border-slate-800"
          />
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
          </div>
        ) : (
          <div className="space-y-4">
            {filtered.map((profile) => (
              <Card key={profile.id} className="bg-slate-900 border-slate-800">
                <CardContent className="p-4">
                  <div className="flex items-start gap-4">
                    <Avatar src={profile.profile_picture} name={profile.display_name || profile.email} size="md" />
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-semibold">{profile.display_name || 'No name'}</span>
                        {profile.username && <span className="text-blue-400 text-sm">@{profile.username}</span>}
                        {/* Current badges */}
                        {(profile.badges || []).map(b => BADGE_CONFIG[b] && (
                          <button
                            key={b}
                            onClick={() => revokeBadge(profile, b)}
                            className="relative group"
                            title={`Remove ${BADGE_CONFIG[b].label}`}
                          >
                            <img src={BADGE_CONFIG[b].image} alt={BADGE_CONFIG[b].label} className="w-6 h-6 object-contain" />
                            <span className="absolute inset-0 bg-red-500/0 group-hover:bg-red-500/20 rounded-full transition-colors flex items-center justify-center">
                              <X className="w-3 h-3 text-red-400 opacity-0 group-hover:opacity-100" />
                            </span>
                          </button>
                        ))}
                      </div>
                      <p className="text-xs text-slate-500 mt-0.5">{profile.email}</p>

                      {/* Badge grant buttons */}
                      <div className="flex flex-wrap gap-1.5 mt-3">
                        {Object.entries(BADGE_CONFIG).map(([id, cfg]) => {
                          const has = profile.badges?.includes(id);
                          return (
                            <button
                              key={id}
                              onClick={() => has ? revokeBadge(profile, id) : grantBadge(profile, id)}
                              title={has ? `Remove ${cfg.label}` : `Grant ${cfg.label}`}
                              className={`flex items-center gap-1.5 px-2 py-1 rounded-lg text-xs border transition-all ${
                                has
                                  ? 'bg-slate-700 border-slate-600 text-slate-300'
                                  : 'bg-slate-800/50 border-slate-700/50 text-slate-500 hover:border-slate-600 hover:text-slate-300'
                              }`}
                            >
                              <img src={cfg.image} alt={cfg.label} className="w-4 h-4 object-contain" />
                              {cfg.label}
                              {has ? <X className="w-3 h-3" /> : <Plus className="w-3 h-3" />}
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}