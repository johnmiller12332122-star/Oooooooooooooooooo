const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useEffect, useRef, useCallback } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Navbar from '../components/navbar/Navbar';
import Sidebar from '../components/chat/Sidebar';
import ChatHeader from '../components/chat/ChatHeader';
import ChatInput from '../components/chat/ChatInput';
import MessageBubble from '../components/chat/MessageBubble';
import NewChatModal from '../components/chat/NewChatModal';
import ProfilePanel from '../components/chat/ProfilePanel';
import EmptyChat from '../components/chat/EmptyChat';
import { Loader2 } from 'lucide-react';

export default function Home() {
  const [currentUser, setCurrentUser] = useState(null);
  const [activeChat, setActiveChat] = useState(null);
  const [showNewChat, setShowNewChat] = useState(false);
  const [profilePanel, setProfilePanel] = useState(null);
  const [showSidebar, setShowSidebar] = useState(true);
  const messagesEndRef = useRef(null);
  const chatInputRef = useRef(null);
  const queryClient = useQueryClient();

  // Auto-focus chat input on any key press
  useEffect(() => {
    const handleKey = (e) => {
      if (!activeChat) return;
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (['Tab', 'Escape', 'Enter', 'ArrowUp', 'ArrowDown'].includes(e.key)) return;
      if (document.activeElement?.tagName === 'INPUT' || document.activeElement?.tagName === 'TEXTAREA') return;
      chatInputRef.current?.focus();
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [activeChat]);

  useEffect(() => {
    db.auth.me().then(async (user) => {
      setCurrentUser(user);
      // Auto-create bot chat if it doesn't exist
      const BOT_EMAIL = 'nexus-bot@nexus.app';
      const allChats = await db.entities.Chat.list();
      const hasBot = allChats.some(c =>
        c.type === 'direct' &&
        c.participants?.includes(user.email) &&
        c.participants?.includes(BOT_EMAIL)
      );
      if (!hasBot) {
        await db.entities.Chat.create({
          type: 'direct',
          participants: [user.email, BOT_EMAIL],
          last_message: '👋 Welcome to Nexus! I\'m the official bot.',
          last_message_time: new Date().toISOString(),
          last_message_by: BOT_EMAIL,
        });
      }
    });
  }, []);

  const { data: profiles = {} } = useQuery({
    queryKey: ['profiles'],
    queryFn: async () => {
      const list = await db.entities.UserProfile.list();
      const map = {};
      list.forEach(p => { map[p.email] = p; });
      return map;
    },
    enabled: !!currentUser,
  });

  const { data: chats = [] } = useQuery({
    queryKey: ['chats'],
    queryFn: async () => {
      const all = await db.entities.Chat.list('-last_message_time');
      return all.filter(c => c.participants?.includes(currentUser.email));
    },
    enabled: !!currentUser,
  });

  const { data: messages = [], isLoading: messagesLoading } = useQuery({
    queryKey: ['messages', activeChat?.id],
    queryFn: () => db.entities.Message.filter({ chat_id: activeChat.id }, 'created_date', 100),
    enabled: !!activeChat,
  });

  // Real-time subscriptions
  useEffect(() => {
    const unsubMsg = db.entities.Message.subscribe((event) => {
      if (event.type === 'create') {
        queryClient.invalidateQueries({ queryKey: ['messages', event.data.chat_id] });
        queryClient.invalidateQueries({ queryKey: ['chats'] });
      }
    });
    const unsubChat = db.entities.Chat.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ['chats'] });
    });
    return () => { unsubMsg(); unsubChat(); };
  }, [queryClient]);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessageMutation = useMutation({
    mutationFn: async (msgData) => {
      await db.entities.Message.create({
        chat_id: activeChat.id,
        sender_email: currentUser.email,
        sender_name: profiles[currentUser.email]?.display_name || currentUser.full_name || currentUser.email,
        ...msgData,
      });
      await db.entities.Chat.update(activeChat.id, {
        last_message: msgData.type === 'image' ? '📷 Image' : msgData.type === 'file' ? '📎 File' : msgData.content,
        last_message_time: new Date().toISOString(),
        last_message_by: currentUser.email,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['messages', activeChat.id] });
      queryClient.invalidateQueries({ queryKey: ['chats'] });
    },
  });

  const handleReact = async (messageId, emoji) => {
    const msg = messages.find(m => m.id === messageId);
    if (!msg) return;
    const reactions = { ...(msg.reactions || {}) };
    const users = reactions[emoji] ? [...reactions[emoji]] : [];
    const idx = users.indexOf(currentUser.email);
    if (idx >= 0) users.splice(idx, 1);
    else users.push(currentUser.email);
    reactions[emoji] = users;
    await db.entities.Message.update(messageId, { reactions });
    queryClient.invalidateQueries({ queryKey: ['messages', activeChat.id] });
  };

  const createChatMutation = useMutation({
    mutationFn: async (chatData) => {
      // Check if direct chat already exists
      if (chatData.type === 'direct') {
        const existing = chats.find(c =>
          c.type === 'direct' &&
          c.participants?.length === 2 &&
          chatData.participants.every(p => c.participants.includes(p))
        );
        if (existing) {
          setActiveChat(existing);
          return;
        }
      }
      const newChat = await db.entities.Chat.create(chatData);
      setActiveChat(newChat);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['chats'] });
    },
  });

  const renderMessages = useCallback(() => {
    return messages.map((msg, i) => {
      const isOwn = msg.sender_email === currentUser?.email;
      const prevMsg = messages[i - 1];
      const showAvatar = !prevMsg || prevMsg.sender_email !== msg.sender_email;

      return (
        <MessageBubble
          key={msg.id}
          message={msg}
          isOwn={isOwn}
          showAvatar={showAvatar}
          senderProfile={profiles[msg.sender_email]}
          currentUserEmail={currentUser?.email}
          onReact={handleReact}
        />
      );
    });
  }, [messages, currentUser, profiles]);

  if (!currentUser) {
    return (
      <div className="h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="h-screen bg-slate-950 flex overflow-hidden pb-16 md:pb-0 md:pt-16">
      <Navbar />
      {/* Sidebar */}
      <div className={`${showSidebar ? 'flex' : 'hidden'} md:flex`}>
        <Sidebar
          chats={chats}
          profiles={profiles}
          currentUserEmail={currentUser.email}
          currentUserProfile={profiles[currentUser.email]}
          activeChatId={activeChat?.id}
          onChatSelect={(chat) => {
            setActiveChat(chat);
            setShowSidebar(false);
          }}
          onNewChat={() => setShowNewChat(true)}
        />
      </div>

      {/* Chat area */}
      <div className={`flex-1 flex flex-col min-w-0 ${!showSidebar ? 'flex' : 'hidden md:flex'}`}>
        {activeChat ? (
          <>
            <ChatHeader
              chat={activeChat}
              profiles={profiles}
              currentUserEmail={currentUser.email}
              onProfileClick={setProfilePanel}
              onBack={() => setShowSidebar(true)}
            />

            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {messagesLoading ? (
                <div className="flex items-center justify-center h-full">
                  <Loader2 className="w-5 h-5 animate-spin text-slate-600" />
                </div>
              ) : messages.length === 0 ? (
                <div className="flex items-center justify-center h-full">
                  <p className="text-sm text-slate-600">No messages yet. Say hello! 👋</p>
                </div>
              ) : (
                renderMessages()
              )}
              <div ref={messagesEndRef} />
            </div>

            <ChatInput
              onSend={(data) => sendMessageMutation.mutate(data)}
              disabled={sendMessageMutation.isPending}
              inputRef={chatInputRef}
            />
          </>
        ) : (
          <EmptyChat />
        )}
      </div>

      {/* Profile panel */}
      {profilePanel && (
        <ProfilePanel
          profile={profilePanel}
          onClose={() => setProfilePanel(null)}
        />
      )}

      {/* New chat modal */}
      <NewChatModal
        open={showNewChat}
        onClose={() => setShowNewChat(false)}
        profiles={profiles}
        currentUserEmail={currentUser.email}
        onCreateChat={(data) => createChatMutation.mutate(data)}
      />
    </div>
  );
}