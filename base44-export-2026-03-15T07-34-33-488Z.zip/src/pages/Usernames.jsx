const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useEffect } from 'react';

import { useQuery } from '@tanstack/react-query';
import Navbar from '../components/navbar/Navbar';
import UsernameDetailsModal from '../components/shop/UsernameDetailsModal';
import Avatar from '../components/chat/Avatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Search, AtSign, TrendingUp, Loader2 } from 'lucide-react';

export default function Usernames() {
  const [currentUser, setCurrentUser] = useState(null);
  const [search, setSearch] = useState('');
  const [selectedUsername, setSelectedUsername] = useState(null);

  useEffect(() => {
    db.auth.me().then(setCurrentUser);
  }, []);

  const { data: usernames = [] } = useQuery({
    queryKey: ['collectibleUsernames'],
    queryFn: () => db.entities.CollectibleUsername.list('-price_usd'),
    enabled: !!currentUser,
  });

  const { data: profiles = {} } = useQuery({
    queryKey: ['profilesMap'],
    queryFn: async () => {
      const list = await db.entities.UserProfile.list();
      const map = {};
      list.forEach(p => { map[p.email] = p; });
      return map;
    },
    enabled: !!currentUser,
  });

  const filteredUsernames = usernames.filter(u =>
    u.username?.toLowerCase().includes(search.toLowerCase())
  );

  if (!currentUser) {
    return (
      <div className="h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20 md:pb-0 md:pt-20">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold">Collectible Usernames</h1>
          <p className="text-slate-400 mt-1">Own your unique @username as an NFT</p>
        </div>

        <div className="relative mb-6">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search usernames..."
            className="pl-10 bg-slate-900 border-slate-800"
          />
        </div>

        <div className="space-y-3">
          {filteredUsernames.map((username) => {
            const owner = profiles[username.owner_email];
            return (
              <Card
                key={username.id}
                className="bg-slate-900 border-slate-800 hover:border-slate-700 transition-colors cursor-pointer"
                onClick={() => setSelectedUsername({ username, owner })}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center">
                        <AtSign className="w-6 h-6 text-slate-400" />
                      </div>
                      <div>
                        <div className="font-semibold text-lg">@{username.username}</div>
                        <div className="flex items-center gap-2 text-sm text-slate-400">
                          <Avatar
                            src={owner?.profile_picture}
                            name={owner?.display_name || owner?.email}
                            size="xs"
                          />
                          <span>{owner?.display_name || owner?.email}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-xl font-bold text-green-400">
                        ${username.price_usd?.toFixed(2)}
                      </div>
                      {username.on_sale && (
                        <Badge className="bg-blue-500/20 text-blue-400 border-blue-500/30 text-xs">
                          For Sale
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {filteredUsernames.length === 0 && (
          <div className="text-center py-16 text-slate-500">
            <p>No usernames found</p>
          </div>
        )}
      </div>

      <UsernameDetailsModal
        username={selectedUsername?.username}
        owner={selectedUsername?.owner}
        open={!!selectedUsername}
        onClose={() => setSelectedUsername(null)}
      />
    </div>
  );
}