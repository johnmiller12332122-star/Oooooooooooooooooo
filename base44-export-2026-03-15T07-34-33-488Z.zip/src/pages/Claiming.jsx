const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useEffect } from 'react';

import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import Navbar from '../components/navbar/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent } from '@/components/ui/card';
import { AtSign, Check, X, Loader2, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

export default function Claiming() {
  const [currentUser, setCurrentUser] = useState(null);
  const [username, setUsername] = useState('');
  const [checking, setChecking] = useState(false);
  const [available, setAvailable] = useState(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    db.auth.me().then(setCurrentUser);
  }, []);

  const { data: myUsernames = [] } = useQuery({
    queryKey: ['myCollectibleUsernames', currentUser?.email],
    queryFn: () => db.entities.CollectibleUsername.filter({ owner_email: currentUser.email }),
    enabled: !!currentUser,
  });

  const checkAvailability = async () => {
    if (!username.trim()) return;
    setChecking(true);
    const existing = await db.entities.CollectibleUsername.filter({ username: username.toLowerCase() });
    if (existing.length > 0) {
      // Check if user already owns it
      if (existing[0].owner_email === currentUser.email) {
        setAvailable('yours');
      } else {
        setAvailable(false);
      }
    } else {
      setAvailable(true);
    }
    setChecking(false);
  };

  const claimMutation = useMutation({
    mutationFn: async () => {
      const price = Math.floor(Math.random() * 500) + 100;
      await db.entities.CollectibleUsername.create({
        username: username.toLowerCase(),
        owner_email: currentUser.email,
        price_usd: price,
        claimed_date: new Date().toISOString(),
        on_sale: false,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myCollectibleUsernames'] });
      queryClient.invalidateQueries({ queryKey: ['collectibleUsernames'] });
      toast.success(`@${username} claimed successfully!`);
      setUsername('');
      setAvailable(null);
    },
  });

  if (!currentUser) {
    return (
      <div className="h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20 md:pb-0 md:pt-20">
      <Navbar />
      
      <div className="max-w-2xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 mb-4">
            <Sparkles className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-3xl font-bold">Claim Your Username</h1>
          <p className="text-slate-400 mt-2">Own a unique collectible username on TDN blockchain</p>
        </div>

        <Card className="bg-slate-900 border-slate-800 mb-6">
          <CardContent className="p-6 space-y-4">
            <div>
              <div className="relative">
                <AtSign className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500" />
                <Input
                  value={username}
                  onChange={(e) => {
                    setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ''));
                    setAvailable(null);
                  }}
                  placeholder="your_username"
                  className="pl-10 bg-slate-800 border-slate-700 text-lg h-12"
                />
              </div>
              <p className="text-xs text-slate-500 mt-2">Letters, numbers, and underscores only</p>
            </div>

            {available !== null && (
              <div className={`flex items-center gap-2 p-3 rounded-lg ${
                available === true ? 'bg-green-500/10 text-green-400' :
                available === 'yours' ? 'bg-blue-500/10 text-blue-400' :
                'bg-red-500/10 text-red-400'
              }`}>
                {available === true ? <Check className="w-5 h-5" /> :
                 available === 'yours' ? <Check className="w-5 h-5" /> :
                 <X className="w-5 h-5" />}
                <span className="font-medium">
                  {available === true ? 'Available to claim!' :
                   available === 'yours' ? "You already own this username!" :
                   'Already taken'}
                </span>
              </div>
            )}

            <div className="flex gap-3">
              <Button
                onClick={checkAvailability}
                disabled={!username.trim() || checking}
                variant="outline"
                className="flex-1 border-slate-700"
              >
                {checking ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Check Availability
              </Button>
              <Button
                onClick={() => claimMutation.mutate()}
                disabled={available !== true || claimMutation.isPending}
                className="flex-1 bg-blue-600 hover:bg-blue-500"
              >
                {claimMutation.isPending ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
                Claim Username
              </Button>
            </div>
          </CardContent>
        </Card>

        <div>
          <h2 className="text-xl font-bold mb-4">My Claimed Usernames ({myUsernames.length})</h2>
          <div className="space-y-3">
            {myUsernames.map((u) => (
              <Card key={u.id} className="bg-slate-900 border-slate-800">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center">
                      <AtSign className="w-5 h-5 text-slate-400" />
                    </div>
                    <div>
                      <div className="font-semibold">@{u.username}</div>
                      <div className="text-xs text-slate-500">
                        Claimed {new Date(u.claimed_date).toLocaleDateString()}
                      </div>
                    </div>
                  </div>
                  <div className="text-green-400 font-bold">
                    ${u.price_usd?.toFixed(2)}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
          {myUsernames.length === 0 && (
            <p className="text-center text-slate-500 py-8">You haven't claimed any usernames yet</p>
          )}
        </div>
      </div>
    </div>
  );
}