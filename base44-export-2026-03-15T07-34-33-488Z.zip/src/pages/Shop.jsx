const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useEffect } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Navbar from '../components/navbar/Navbar';
import PurchaseSuccessModal from '../components/shop/PurchaseSuccessModal';
import CartDrawer from '../components/shop/CartDrawer';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Search, Wallet, Loader2, ShoppingCart, Filter, ExternalLink, Plus } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

export default function Shop() {
  const [currentUser, setCurrentUser] = useState(null);
  const [search, setSearch] = useState('');
  const [purchaseSuccess, setPurchaseSuccess] = useState(null);
  const [walletConnected, setWalletConnected] = useState(false);
  const [cart, setCart] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const queryClient = useQueryClient();

  useEffect(() => {
    db.auth.me().then(setCurrentUser);
  }, []);

  const { data: listings = [] } = useQuery({
    queryKey: ['nftListings'],
    queryFn: () => db.entities.NFTListing.list(),
    enabled: !!currentUser,
  });

  // Real-time listing updates
  useEffect(() => {
    const unsub = db.entities.NFTListing.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ['nftListings'] });
    });
    return unsub;
  }, [queryClient]);

  const filteredListings = listings.filter(nft =>
    nft.name?.toLowerCase().includes(search.toLowerCase()) ||
    nft.collection?.toLowerCase().includes(search.toLowerCase())
  );

  const connectWallet = async () => {
    if (typeof window.ethereum !== 'undefined') {
      try {
        await window.ethereum.request({ method: 'eth_requestAccounts' });
        setWalletConnected(true);
        toast.success('Wallet connected!');
      } catch (err) {
        toast.error('Failed to connect wallet');
      }
    } else {
      toast.error('Please install MetaMask or Ledger extension');
    }
  };

  const addToCart = (listing) => {
    if (listing.remaining <= 0) { toast.error('Sold out!'); return; }
    if (cart.find(c => c.id === listing.id)) { toast.info('Already in cart'); return; }
    setCart(prev => [...prev, listing]);
    toast.success(`${listing.name} added to cart`);
  };

  const purchaseOne = async (listing) => {
    if (listing.remaining <= 0) throw new Error('Sold out!');
    const tokenId = listing.total_supply - listing.remaining + 1;
    await db.entities.NFTInventory.create({
      owner_email: currentUser.email,
      nft_name: listing.name,
      nft_image: listing.image_url,
      collection: listing.collection,
      token_id: tokenId.toString(),
      symbol: listing.symbol,
      total_supply: listing.total_supply,
      price_usd: listing.price_usd,
      purchase_date: new Date().toISOString(),
      visible_on_profile: true,
    });
    await db.entities.NFTListing.update(listing.id, { remaining: listing.remaining - 1 });
    return { ...listing, token_id: tokenId };
  };

  const purchaseMutation = useMutation({
    mutationFn: purchaseOne,
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['nftListings'] });
      queryClient.invalidateQueries({ queryKey: ['myInventory'] });
      setPurchaseSuccess(data);
    },
    onError: (err) => toast.error(err.message),
  });

  const checkoutMutation = useMutation({
    mutationFn: async () => {
      for (const item of cart) {
        const fresh = listings.find(l => l.id === item.id);
        if (fresh) await purchaseOne(fresh);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['nftListings'] });
      queryClient.invalidateQueries({ queryKey: ['myInventory'] });
      toast.success(`Purchased ${cart.length} NFTs!`);
      setCart([]);
      setCartOpen(false);
    },
    onError: (err) => toast.error(err.message),
  });

  if (!currentUser) return (
    <div className="h-screen bg-slate-950 flex items-center justify-center">
      <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
    </div>
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20 md:pb-0 md:pt-20">
      <Navbar />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
          <div>
            <h1 className="text-3xl font-bold">NFT Marketplace</h1>
            <p className="text-slate-400 mt-1">Browse and discover collectible NFTs</p>
          </div>
          
          <div className="flex gap-2">
            <Button
              onClick={connectWallet}
              className={walletConnected ? 'bg-green-600 hover:bg-green-500' : 'bg-slate-700 hover:bg-slate-600'}
            >
              <Wallet className="w-4 h-4 mr-2" />
              {walletConnected ? 'Wallet Connected' : 'Connect Wallet'}
            </Button>
            <Button
              onClick={() => setCartOpen(true)}
              className="bg-blue-600 hover:bg-blue-500 relative"
            >
              <ShoppingCart className="w-4 h-4 mr-2" />
              Cart
              {cart.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[10px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                  {cart.length}
                </span>
              )}
            </Button>
          </div>
        </div>

        <div className="flex gap-3 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search NFTs by name or collection..."
              className="pl-10 bg-slate-900 border-slate-800"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredListings.map((listing) => (
            <Card key={listing.id} className="bg-slate-900 border-slate-800 hover:border-slate-700 transition-all group">
              <CardContent className="p-0">
                <Link to={createPageUrl(`NFTDetail?id=${listing.id}`)} className="block">
                  <div className="aspect-square bg-gradient-to-br from-blue-900/20 to-purple-900/20 flex items-center justify-center relative overflow-hidden">
                    {listing.image_url ? (
                      <img
                        src={listing.image_url}
                        alt={listing.name}
                        className={`w-full h-full object-contain p-8 transition-transform duration-300 ${listing.name === 'Scared Cat' ? 'group-hover:animate-bounce' : 'group-hover:scale-105'}`}
                      />
                    ) : (
                      <div className="text-6xl">🎨</div>
                    )}
                    <div className="absolute top-3 right-3">
                      <Badge className="bg-slate-800/80 text-slate-300 border-slate-700 text-[10px]">
                        {listing.remaining}/{listing.total_supply} left
                      </Badge>
                    </div>
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors flex items-center justify-center opacity-0 group-hover:opacity-100">
                      <span className="text-xs font-medium text-white bg-black/60 px-3 py-1 rounded-full flex items-center gap-1">
                        <ExternalLink className="w-3 h-3" /> View Details
                      </span>
                    </div>
                  </div>
                </Link>
                <div className="p-4 space-y-3">
                  <div>
                    <Link to={createPageUrl(`NFTDetail?id=${listing.id}`)} className="hover:text-blue-400 transition-colors">
                      <h3 className="font-bold text-lg">{listing.name}</h3>
                    </Link>
                    <p className="text-sm text-cyan-400">{listing.collection}</p>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <div className="text-xl font-bold text-green-400">
                      {listing.currency === 'TON' ? `${listing.price_usd} 💎` : `$${listing.price_usd}`}
                    </div>
                    <div className="flex gap-1.5">
                      <Button
                        onClick={() => addToCart(listing)}
                        disabled={listing.remaining === 0}
                        variant="outline"
                        size="sm"
                        className="border-slate-700 hover:bg-slate-800"
                        title="Add to cart"
                      >
                        <Plus className="w-4 h-4" />
                      </Button>
                      <Button
                        onClick={() => purchaseMutation.mutate(listing)}
                        disabled={listing.remaining === 0 || purchaseMutation.isPending}
                        className="bg-blue-600 hover:bg-blue-500"
                        size="sm"
                      >
                        {purchaseMutation.isPending ? (
                          <Loader2 className="w-4 h-4 animate-spin" />
                        ) : listing.remaining === 0 ? (
                          'Sold Out'
                        ) : (
                          <><ShoppingCart className="w-4 h-4 mr-1" />Buy</>
                        )}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredListings.length === 0 && (
          <div className="text-center py-16 text-slate-500">
            <p>No NFTs available</p>
          </div>
        )}
      </div>

      <CartDrawer
        cart={cart}
        open={cartOpen}
        onClose={() => setCartOpen(false)}
        onRemove={(i) => setCart(prev => prev.filter((_, idx) => idx !== i))}
        onCheckout={() => checkoutMutation.mutate()}
        isCheckingOut={checkoutMutation.isPending}
      />

      <PurchaseSuccessModal
        nft={purchaseSuccess}
        open={!!purchaseSuccess}
        onClose={() => setPurchaseSuccess(null)}
      />
    </div>
  );
}