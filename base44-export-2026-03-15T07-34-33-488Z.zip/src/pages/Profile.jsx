const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useEffect, useRef } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Navbar from '../components/navbar/Navbar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import Avatar from '../components/chat/Avatar';
import NFTCard from '../components/chat/NFTCard';
import { ArrowLeft, Camera, Save, AtSign, Wallet, Shield, Plus, X, Loader2, Link2, ShoppingBag, UserPlus } from 'lucide-react';

import { BADGE_CONFIG } from '../components/shared/badgeConfig';
import BadgeIcon from '../components/shared/BadgeIcon';
import PurchaseHistory from '../components/profile/PurchaseHistory';
import AddPeople from '../components/profile/AddPeople';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';

export default function Profile() {
  const [currentUser, setCurrentUser] = useState(null);
  const [form, setForm] = useState({
    display_name: '',
    username: '',
    bio: '',
    profile_picture: '',
    theme_color: '#3b82f6',
    wallet_address: '',
  });
  const [activeTab, setActiveTab] = useState('edit');
  const [nftName, setNftName] = useState('');
  const [nftCollection, setNftCollection] = useState('');
  const [nftImage, setNftImage] = useState('');
  const [nftTokenId, setNftTokenId] = useState('');
  const fileRef = useRef(null);
  const queryClient = useQueryClient();

  useEffect(() => {
    db.auth.me().then(setCurrentUser);
  }, []);

  const { data: profile, isLoading } = useQuery({
    queryKey: ['myProfile', currentUser?.email],
    queryFn: async () => {
      const list = await db.entities.UserProfile.filter({ email: currentUser.email });
      return list[0] || null;
    },
    enabled: !!currentUser,
  });

  const { data: socialConnections = [] } = useQuery({
    queryKey: ['mySocial', currentUser?.email],
    queryFn: () => db.entities.SocialConnection.filter({ user_email: currentUser.email }),
    enabled: !!currentUser,
  });

  const { data: myUsernames = [] } = useQuery({
    queryKey: ['myUsernames', currentUser?.email],
    queryFn: () => db.entities.CollectibleUsername.filter({ owner_email: currentUser.email }),
    enabled: !!currentUser,
  });

  const { data: myInventory = [] } = useQuery({
    queryKey: ['myInventory', currentUser?.email],
    queryFn: () => db.entities.NFTInventory.filter({ owner_email: currentUser.email }),
    enabled: !!currentUser,
  });

  // Real-time updates for inventory and usernames
  useEffect(() => {
    if (!currentUser) return;
    const unsubInv = db.entities.NFTInventory.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ['myInventory'] });
    });
    const unsubUn = db.entities.CollectibleUsername.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ['myUsernames'] });
    });
    const unsubProfile = db.entities.UserProfile.subscribe(() => {
      queryClient.invalidateQueries({ queryKey: ['myProfile'] });
      queryClient.invalidateQueries({ queryKey: ['profiles'] });
    });
    return () => { unsubInv(); unsubUn(); unsubProfile(); };
  }, [currentUser, queryClient]);

  useEffect(() => {
    if (profile) {
      setForm({
        display_name: profile.display_name || '',
        username: profile.username || '',
        bio: profile.bio || '',
        profile_picture: profile.profile_picture || '',
        theme_color: profile.theme_color || '#3b82f6',
        wallet_address: profile.wallet_address || '',
      });
    } else if (currentUser) {
      setForm(f => ({
        ...f,
        display_name: currentUser.full_name || '',
      }));
    }
  }, [profile, currentUser]);

  const saveMutation = useMutation({
    mutationFn: async () => {
      // Validate username
      if (form.username) {
        const usernameRegex = /^[a-zA-Z0-9_]+$/;
        if (!usernameRegex.test(form.username)) {
          throw new Error('Username can only contain letters, numbers, and underscores');
        }
        // Check uniqueness
        const existing = await db.entities.UserProfile.filter({ username: form.username });
        if (existing.length > 0 && existing[0].email !== currentUser.email) {
          throw new Error('Username is already taken');
        }
      }

      const data = {
        ...form,
        email: currentUser.email,
        status: 'online',
        last_seen: new Date().toISOString(),
        nfts: profile?.nfts || [],
        badges: profile?.badges || [],
      };

      if (profile) {
        await db.entities.UserProfile.update(profile.id, data);
      } else {
        await db.entities.UserProfile.create(data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['myProfile'] });
      queryClient.invalidateQueries({ queryKey: ['profiles'] });
      toast.success('Profile saved');
    },
    onError: (err) => {
      toast.error(err.message);
    },
  });

  const handleAvatarUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const { file_url } = await db.integrations.Core.UploadFile({ file });
    setForm(f => ({ ...f, profile_picture: file_url }));
  };

  const handleAddNFT = async () => {
    if (!nftName.trim()) return;
    const nfts = [...(profile?.nfts || []), {
      name: nftName.trim(),
      collection: nftCollection.trim(),
      image_url: nftImage.trim(),
      token_id: nftTokenId.trim(),
    }];
    if (profile) {
      await db.entities.UserProfile.update(profile.id, { nfts });
    }
    queryClient.invalidateQueries({ queryKey: ['myProfile'] });
    setNftName('');
    setNftCollection('');
    setNftImage('');
    setNftTokenId('');
    toast.success('NFT added');
  };

  const handleRemoveNFT = async (index) => {
    const nfts = [...(profile?.nfts || [])];
    nfts.splice(index, 1);
    if (profile) {
      await db.entities.UserProfile.update(profile.id, { nfts });
    }
    queryClient.invalidateQueries({ queryKey: ['myProfile'] });
  };

  if (!currentUser || isLoading) {
    return (
      <div className="h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
      </div>
    );
  }

  const toggleSocialDisplay = async (connection, field) => {
    await db.entities.SocialConnection.update(connection.id, {
      [field]: !connection[field]
    });
    queryClient.invalidateQueries({ queryKey: ['mySocial'] });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20 md:pb-0 md:pt-20">
      <Navbar />
      {/* Header */}
      <div className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-10">
        <div className="max-w-2xl mx-auto px-4 h-14 flex items-center gap-3">
          <Link to={createPageUrl('Home')}>
            <Button variant="ghost" size="icon" className="text-slate-400 hover:text-slate-200 h-8 w-8">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <h1 className="font-semibold">Profile</h1>
        </div>
        {/* Tabs */}
        <div className="max-w-2xl mx-auto px-4 flex gap-1 pb-0">
          {[
            { id: 'edit', label: 'Edit Profile', icon: <Save className="w-3.5 h-3.5" /> },
            { id: 'history', label: 'Purchases', icon: <ShoppingBag className="w-3.5 h-3.5" /> },
            { id: 'people', label: 'Add People', icon: <UserPlus className="w-3.5 h-3.5" /> },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-1.5 px-4 py-2.5 text-sm font-medium border-b-2 transition-colors ${
                activeTab === tab.id
                  ? 'border-blue-500 text-blue-400'
                  : 'border-transparent text-slate-500 hover:text-slate-300'
              }`}
            >
              {tab.icon}
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-8 space-y-8">
        {activeTab === 'history' && <PurchaseHistory currentUser={currentUser} />}
        {activeTab === 'people' && <AddPeople currentUser={currentUser} profile={profile} />}

        {activeTab === 'edit' && <>
        {/* Avatar section */}
        <div className="flex flex-col items-center">
          <div className="relative group">
            <Avatar
              src={form.profile_picture}
              name={form.display_name || currentUser.email}
              size="2xl"
            />
            <button
              onClick={() => fileRef.current?.click()}
              className="absolute inset-0 bg-black/50 rounded-full opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center"
            >
              <Camera className="w-6 h-6 text-white" />
            </button>
            <input type="file" ref={fileRef} accept="image/*" onChange={handleAvatarUpload} className="hidden" />
          </div>
          <p className="text-xs text-slate-500 mt-3">Click to change avatar</p>
          {profile?.badges?.length > 0 && (
            <div className="flex flex-wrap gap-2 justify-center mt-3">
              {profile.badges.map((b) => (
                <BadgeIcon key={b} badgeKey={b} cfg={BADGE_CONFIG[b]} size={8} />
              ))}
            </div>
          )}
        </div>

        {/* Form */}
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6 space-y-5">
            <div>
              <Label className="text-slate-300 text-xs">Display Name</Label>
              <Input
                value={form.display_name}
                onChange={(e) => setForm(f => ({ ...f, display_name: e.target.value }))}
                className="mt-1.5 bg-slate-800 border-slate-700 text-slate-100"
                placeholder="Your name"
              />
            </div>

            <div>
              <Label className="text-slate-300 text-xs flex items-center gap-1.5">
                <AtSign className="w-3 h-3" /> Username
              </Label>
              <Input
                value={form.username}
                onChange={(e) => setForm(f => ({ ...f, username: e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '') }))}
                className="mt-1.5 bg-slate-800 border-slate-700 text-slate-100"
                placeholder="your_username"
              />
              <p className="text-[10px] text-slate-600 mt-1">Letters, numbers, underscores only</p>
            </div>

            <div>
              <Label className="text-slate-300 text-xs">Bio</Label>
              <Textarea
                value={form.bio}
                onChange={(e) => setForm(f => ({ ...f, bio: e.target.value }))}
                className="mt-1.5 bg-slate-800 border-slate-700 text-slate-100 resize-none h-20"
                placeholder="Tell people about yourself..."
              />
            </div>

            <div>
              <Label className="text-slate-300 text-xs flex items-center gap-1.5">
                <Wallet className="w-3 h-3" /> Wallet Address
              </Label>
              <Input
                value={form.wallet_address}
                onChange={(e) => setForm(f => ({ ...f, wallet_address: e.target.value }))}
                className="mt-1.5 bg-slate-800 border-slate-700 text-slate-100 font-mono text-xs"
                placeholder="0x..."
              />
            </div>

            <Button
              onClick={() => saveMutation.mutate()}
              disabled={saveMutation.isPending}
              className="w-full bg-blue-600 hover:bg-blue-500 h-11"
            >
              {saveMutation.isPending ? (
                <Loader2 className="w-4 h-4 animate-spin mr-2" />
              ) : (
                <Save className="w-4 h-4 mr-2" />
              )}
              Save Profile
            </Button>
          </CardContent>
        </Card>

        {/* Owned Usernames - Prominent */}
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <h3 className="font-semibold flex items-center gap-2 mb-4">
              <AtSign className="w-5 h-5 text-blue-400" />
              Owned Usernames
            </h3>
            {myUsernames.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-4">No usernames owned yet</p>
            ) : (
              <div className="space-y-2">
                {myUsernames.map((u) => (
                  <div 
                    key={u.id} 
                    className="flex items-center justify-between p-4 bg-slate-800/50 rounded-lg border border-slate-700/50"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-slate-700 flex items-center justify-center">
                        <AtSign className="w-5 h-5 text-blue-400" />
                      </div>
                      <div>
                        <span className="font-semibold text-lg">@{u.username}</span>
                        <p className="text-xs text-slate-500">{u.visible_on_profile ? 'Shown on profile' : 'Hidden from profile'}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className="text-emerald-400 font-bold">${u.price_usd?.toFixed(2)}</span>
                      <Switch
                        checked={!!u.visible_on_profile}
                        onCheckedChange={async (val) => {
                          await db.entities.CollectibleUsername.update(u.id, { visible_on_profile: val });
                          queryClient.invalidateQueries({ queryKey: ['myUsernames'] });
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* NFT Inventory */}
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <h3 className="font-semibold flex items-center gap-2 mb-4">
              <Shield className="w-5 h-5 text-purple-400" />
              NFT Inventory
            </h3>
            {myInventory.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-8">
                No NFTs in inventory. Visit the Shop to purchase!
              </p>
            ) : (
              <div className="space-y-3">
                {myInventory.map((item) => (
                  <div key={item.id} className="flex items-center gap-3 bg-slate-800/50 rounded-lg border border-slate-700/50 p-3">
                    <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-purple-900/30 to-blue-900/30 flex items-center justify-center shrink-0 overflow-hidden">
                      {item.nft_image ? (
                        <img src={item.nft_image} alt={item.nft_name} className="w-full h-full object-contain" />
                      ) : (
                        <div className="text-2xl">🎨</div>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm truncate">{item.nft_name}</div>
                      <div className="text-xs text-cyan-400">{item.collection}</div>
                      <div className="text-xs text-slate-500">#{item.token_id}</div>
                    </div>
                    <div className="flex flex-col items-end gap-1 shrink-0">
                      <Switch
                        checked={item.visible_on_profile !== false}
                        onCheckedChange={async (val) => {
                          await db.entities.NFTInventory.update(item.id, { visible_on_profile: val });
                          queryClient.invalidateQueries({ queryKey: ['myInventory'] });
                        }}
                      />
                      <span className="text-[10px] text-slate-500">{item.visible_on_profile !== false ? 'On profile' : 'Hidden'}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Social Connections */}
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="p-6">
            <h3 className="font-semibold text-sm flex items-center gap-2 mb-4">
              <Link2 className="w-4 h-4 text-purple-400" />
              Social Connections
            </h3>
            {socialConnections.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-4">No social accounts linked yet</p>
            ) : (
              <div className="space-y-3">
                {socialConnections.map((conn) => (
                  <div key={conn.id} className="bg-slate-800/50 rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div>
                        <div className="font-medium capitalize">{conn.platform}</div>
                        <div className="text-sm text-slate-400">@{conn.platform_username}</div>
                      </div>
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30">
                        Connected
                      </Badge>
                    </div>
                    {conn.followers !== undefined && (
                      <div className="flex gap-4 text-xs text-slate-500">
                        <span>{conn.followers} Followers</span>
                        <span>{conn.following} Following</span>
                        <span>{conn.likes} Likes</span>
                      </div>
                    )}
                    <div className="flex items-center justify-between pt-2 border-t border-slate-700">
                      <Label className="text-xs text-slate-400">Display on profile</Label>
                      <Switch
                        checked={conn.display_on_profile}
                        onCheckedChange={() => toggleSocialDisplay(conn, 'display_on_profile')}
                      />
                    </div>
                    <div className="flex items-center justify-between">
                      <Label className="text-xs text-slate-400">Display details on profile</Label>
                      <Switch
                        checked={conn.show_stats}
                        onCheckedChange={() => toggleSocialDisplay(conn, 'show_stats')}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </>}
      </div>
    </div>
  );
}