const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useEffect } from 'react';

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Navbar from '../components/navbar/Navbar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowLeft, ShoppingCart, Loader2, Layers, Hash, Wallet, Package, Tag, Cpu } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { toast } from 'sonner';
import { format } from 'date-fns';

export default function NFTDetail() {
  const [currentUser, setCurrentUser] = useState(null);
  const navigate = useNavigate();
  const params = new URLSearchParams(window.location.search);
  const id = params.get('id');
  const queryClient = useQueryClient();

  useEffect(() => {
    db.auth.me().then(setCurrentUser);
  }, []);

  const { data: listing, isLoading } = useQuery({
    queryKey: ['nftListing', id],
    queryFn: async () => {
      const all = await db.entities.NFTListing.list();
      return all.find(n => n.id === id) || null;
    },
    enabled: !!id,
  });

  const purchaseMutation = useMutation({
    mutationFn: async () => {
      if (listing.remaining <= 0) throw new Error('Sold out!');
      const tokenId = listing.total_supply - listing.remaining + 1;
      await db.entities.NFTInventory.create({
        owner_email: currentUser.email,
        nft_name: listing.name,
        nft_image: listing.image_url,
        collection: listing.collection,
        token_id: tokenId.toString(),
        symbol: listing.symbol,
        total_supply: listing.total_supply,
        price_usd: listing.price_usd,
        purchase_date: new Date().toISOString(),
        visible_on_profile: true,
      });
      await db.entities.NFTListing.update(listing.id, { remaining: listing.remaining - 1 });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['nftListing', id] });
      queryClient.invalidateQueries({ queryKey: ['nftListings'] });
      queryClient.invalidateQueries({ queryKey: ['myInventory'] });
      toast.success('NFT purchased successfully!');
    },
    onError: (err) => toast.error(err.message),
  });

  if (isLoading || !listing) {
    return (
      <div className="h-screen bg-slate-950 flex items-center justify-center">
        <Loader2 className="w-6 h-6 animate-spin text-blue-500" />
      </div>
    );
  }

  const soldPercentage = Math.round(((listing.total_supply - listing.remaining) / listing.total_supply) * 100);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 pb-20 md:pb-0 md:pt-20">
      <Navbar />

      <div className="border-b border-slate-800 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-10 md:top-20">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center gap-3">
          <Link to={createPageUrl('Shop')}>
            <Button variant="ghost" size="icon" className="text-slate-400 hover:text-slate-200 h-8 w-8">
              <ArrowLeft className="w-4 h-4" />
            </Button>
          </Link>
          <h1 className="font-semibold truncate">{listing.name}</h1>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Artwork */}
        <div>
          <div className="aspect-square rounded-2xl bg-gradient-to-br from-blue-900/30 to-purple-900/30 border border-slate-800 flex items-center justify-center overflow-hidden">
            {listing.image_url ? (
              <img src={listing.image_url} alt={listing.name} className="w-full h-full object-contain p-8" />
            ) : (
              <div className="text-8xl">🎨</div>
            )}
          </div>
        </div>

        {/* Details */}
        <div className="flex flex-col gap-6">
          <div>
            <p className="text-cyan-400 font-medium mb-1">{listing.collection}</p>
            <h2 className="text-3xl font-bold">{listing.name}</h2>
            {listing.symbol && (
              <Badge className="mt-2 bg-slate-800 text-slate-300 border-slate-700">{listing.symbol}</Badge>
            )}
          </div>

          {/* Price & Buy */}
          <Card className="bg-slate-900 border-slate-800">
            <CardContent className="p-5 space-y-4">
              <div className="flex items-end justify-between">
                <div>
                  <p className="text-xs text-slate-500 mb-1">Current Price</p>
                  <p className="text-4xl font-bold text-green-400">${listing.price_usd}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-slate-500 mb-1">Availability</p>
                  <p className="text-lg font-semibold">
                    <span className="text-white">{listing.remaining}</span>
                    <span className="text-slate-500"> / {listing.total_supply}</span>
                  </p>
                </div>
              </div>

              {/* Supply bar */}
              <div>
                <div className="w-full bg-slate-800 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-blue-500 to-purple-500 h-2 rounded-full transition-all"
                    style={{ width: `${soldPercentage}%` }}
                  />
                </div>
                <p className="text-xs text-slate-500 mt-1">{soldPercentage}% sold</p>
              </div>

              <Button
                onClick={() => purchaseMutation.mutate()}
                disabled={listing.remaining === 0 || purchaseMutation.isPending || !currentUser}
                className="w-full bg-blue-600 hover:bg-blue-500 h-11 text-base"
              >
                {purchaseMutation.isPending ? (
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                ) : listing.remaining === 0 ? (
                  'Sold Out'
                ) : (
                  <>
                    <ShoppingCart className="w-4 h-4 mr-2" />
                    Buy Now
                  </>
                )}
              </Button>
            </CardContent>
          </Card>

          {/* Metadata */}
          <Card className="bg-slate-900 border-slate-800">
            <CardContent className="p-5">
              <h3 className="font-semibold mb-4 text-slate-300">Token Details</h3>
              <div className="space-y-3">
                <MetaRow icon={<Hash className="w-4 h-4 text-blue-400" />} label="Next Token ID" value={`#${listing.total_supply - listing.remaining + 1}`} />
                <MetaRow icon={<Layers className="w-4 h-4 text-purple-400" />} label="Total Supply" value={listing.total_supply} />
                <MetaRow icon={<Package className="w-4 h-4 text-cyan-400" />} label="Remaining" value={listing.remaining} />
                <MetaRow icon={<Tag className="w-4 h-4 text-green-400" />} label="Symbol" value={listing.symbol || '—'} />
                <MetaRow icon={<Cpu className="w-4 h-4 text-orange-400" />} label="Blockchain" value={listing.blockchain || 'TDN Blockchain (level 1)'} />
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

function MetaRow({ icon, label, value }) {
  return (
    <div className="flex items-center justify-between py-2 border-b border-slate-800 last:border-0">
      <div className="flex items-center gap-2 text-slate-400 text-sm">
        {icon}
        {label}
      </div>
      <span className="text-slate-200 font-mono text-sm">{value}</span>
    </div>
  );
}