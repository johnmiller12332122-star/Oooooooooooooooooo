export const BADGE_CONFIG = {
  verified: {
    label: 'Verified',
    description: 'This user has been verified by the Nexus team.',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/d26f0d0a8_image.png',
    inline: true,
  },
  bug_hunter: {
    label: 'Bug Hunter',
    description: 'Awarded for finding and reporting bugs in Nexus.',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/4d2e7f0ae_image.png',
  },
  bug_hunter_blue: {
    label: 'Bug Hunter II',
    description: 'Awarded for finding critical bugs in Nexus.',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/fdcd91746_image.png',
  },
  bug_hunter_gold: {
    label: 'Bug Hunter III',
    description: 'Gold tier — awarded for exceptional bug hunting contributions.',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/282dd1530_image.png',
  },
  moderator: {
    label: 'Moderator',
    description: 'An official Nexus moderator who helps maintain the community.',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/29107cda0_image.png',
  },
  staff: {
    label: 'Staff',
    description: 'A member of the official Nexus staff team.',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/c972ca94d_image.png',
  },
  og: {
    label: 'OG',
    description: 'One of the original early users of Nexus.',
    image: 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69b2114b28fd422c2d2b0a73/c227339e2_image.png',
  },
};