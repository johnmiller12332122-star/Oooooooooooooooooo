import React, { useState } from 'react';

export default function BadgeIcon({ badgeKey, cfg, size = 7 }) {
  const [hover, setHover] = useState(false);
  if (!cfg) return null;

  return (
    <div
      className="relative inline-flex items-center"
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
    >
      <img
        src={cfg.image}
        alt={cfg.label}
        className={`w-${size} h-${size} object-contain`}
        style={{ mixBlendMode: 'screen', filter: 'drop-shadow(0 0 2px rgba(0,0,0,0.5))' }}
      />
      {hover && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 z-50 pointer-events-none">
          <div className="bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 shadow-xl w-44 text-center">
            <p className="text-white text-xs font-semibold mb-0.5">{cfg.label}</p>
            <p className="text-slate-400 text-[11px] leading-tight">{cfg.description}</p>
          </div>
          <div className="w-2 h-2 bg-slate-800 border-r border-b border-slate-600 rotate-45 mx-auto -mt-1" />
        </div>
      )}
    </div>
  );
}