import React from 'react';
import { Check, X, ArrowRightLeft, Package, AtSign, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';

const statusColors = {
  pending: 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20',
  accepted: 'bg-green-500/10 text-green-400 border-green-500/20',
  declined: 'bg-red-500/10 text-red-400 border-red-500/20',
  cancelled: 'bg-slate-500/10 text-slate-400 border-slate-500/20',
};

function ItemPreview({ type, nftName, nftImage, nftCollection, username, currencyAmount, currencySymbol }) {
  if (type === 'nft') return (
    <div className="flex items-center gap-2">
      {nftImage ? (
        <img src={nftImage} alt={nftName} className="w-10 h-10 rounded-lg object-cover" />
      ) : (
        <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center">
          <Package className="w-4 h-4 text-slate-400" />
        </div>
      )}
      <div>
        <p className="text-sm font-medium text-white truncate max-w-[140px]">{nftName}</p>
        <p className="text-xs text-slate-400 truncate max-w-[140px]">{nftCollection}</p>
      </div>
    </div>
  );
  if (type === 'username') return (
    <div className="flex items-center gap-2">
      <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center">
        <AtSign className="w-4 h-4 text-blue-400" />
      </div>
      <p className="text-sm font-medium text-white">@{username}</p>
    </div>
  );
  if (type === 'currency') return (
    <div className="flex items-center gap-2">
      <div className="w-10 h-10 rounded-lg bg-green-500/20 flex items-center justify-center">
        <DollarSign className="w-4 h-4 text-green-400" />
      </div>
      <p className="text-sm font-medium text-white">{currencyAmount} {currencySymbol}</p>
    </div>
  );
  return null;
}

export default function TradeCard({ trade, currentUserEmail, profiles, onAccept, onDecline, onCancel }) {
  const isIncoming = trade.to_email === currentUserEmail;
  const otherEmail = isIncoming ? trade.from_email : trade.to_email;
  const otherName = profiles[otherEmail]?.display_name || otherEmail;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <div className="text-sm text-slate-400">
          {isIncoming ? (
            <span>From <span className="text-white font-medium">{otherName}</span></span>
          ) : (
            <span>To <span className="text-white font-medium">{otherName}</span></span>
          )}
        </div>
        <span className={`text-xs px-2 py-0.5 rounded-full border ${statusColors[trade.status]}`}>
          {trade.status}
        </span>
      </div>

      {/* Trade items */}
      <div className="flex items-center gap-3">
        <div className="flex-1 bg-slate-800 rounded-lg p-3">
          <p className="text-xs text-slate-500 mb-2">Offering</p>
          <ItemPreview
            type={trade.offer_item_type}
            nftName={trade.offer_nft_name}
            nftImage={trade.offer_nft_image}
            nftCollection={trade.offer_nft_collection}
            username={trade.offer_username}
          />
        </div>
        <ArrowRightLeft className="w-4 h-4 text-slate-500 flex-shrink-0" />
        <div className="flex-1 bg-slate-800 rounded-lg p-3">
          <p className="text-xs text-slate-500 mb-2">Wants</p>
          <ItemPreview
            type={trade.request_item_type}
            nftName={trade.request_nft_name}
            nftImage={trade.request_nft_image}
            nftCollection={trade.request_nft_collection}
            username={trade.request_username}
            currencyAmount={trade.request_currency_amount}
            currencySymbol={trade.request_currency_symbol}
          />
        </div>
      </div>

      {trade.message && (
        <p className="text-xs text-slate-400 mt-3 bg-slate-800 rounded px-3 py-2 italic">"{trade.message}"</p>
      )}

      {/* Actions */}
      {trade.status === 'pending' && (
        <div className="flex gap-2 mt-3">
          {isIncoming ? (
            <>
              <Button size="sm" onClick={onAccept} className="flex-1 bg-green-600 hover:bg-green-700">
                <Check className="w-3 h-3 mr-1" /> Accept
              </Button>
              <Button size="sm" variant="outline" onClick={onDecline} className="flex-1 border-red-500/30 text-red-400 hover:bg-red-500/10">
                <X className="w-3 h-3 mr-1" /> Decline
              </Button>
            </>
          ) : (
            <Button size="sm" variant="outline" onClick={onCancel} className="border-slate-700 text-slate-400 hover:bg-slate-800">
              <X className="w-3 h-3 mr-1" /> Cancel
            </Button>
          )}
        </div>
      )}
    </div>
  );
}