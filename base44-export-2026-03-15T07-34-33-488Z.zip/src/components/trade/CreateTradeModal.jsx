const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState } from 'react';

import { Button } from '@/components/ui/button';
import { X, Package, AtSign, DollarSign, ChevronDown } from 'lucide-react';

export default function CreateTradeModal({ currentUser, profiles, myNFTs, myUsernames, onClose, onCreated }) {
  const [step, setStep] = useState(1); // 1=pick recipient, 2=pick offer, 3=pick request
  const [recipientEmail, setRecipientEmail] = useState('');
  const [search, setSearch] = useState('');
  const [offerType, setOfferType] = useState('nft'); // 'nft' | 'username'
  const [offerNFT, setOfferNFT] = useState(null);
  const [offerUsername, setOfferUsername] = useState(null);
  const [requestType, setRequestType] = useState('nft'); // 'nft' | 'username' | 'currency'
  const [requestNFTId, setRequestNFTId] = useState('');
  const [requestNFTName, setRequestNFTName] = useState('');
  const [requestNFTImage, setRequestNFTImage] = useState('');
  const [requestNFTCollection, setRequestNFTCollection] = useState('');
  const [requestUsername, setRequestUsername] = useState('');
  const [requestAmount, setRequestAmount] = useState('');
  const [requestSymbol, setRequestSymbol] = useState('USD');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [recipientNFTs, setRecipientNFTs] = useState([]);
  const [recipientUsernames, setRecipientUsernames] = useState([]);

  const otherProfiles = Object.values(profiles).filter(p => p.email !== currentUser.email);
  const filtered = otherProfiles.filter(p =>
    p.email.toLowerCase().includes(search.toLowerCase()) ||
    (p.display_name || '').toLowerCase().includes(search.toLowerCase())
  );

  const selectRecipient = async (email) => {
    setRecipientEmail(email);
    const nfts = await db.entities.NFTInventory.filter({ owner_email: email });
    const uns = await db.entities.CollectibleUsername.filter({ owner_email: email });
    setRecipientNFTs(nfts);
    setRecipientUsernames(uns);
    setStep(2);
  };

  const handleSubmit = async () => {
    setLoading(true);
    const recipientProfile = profiles[recipientEmail];
    const payload = {
      from_email: currentUser.email,
      to_email: recipientEmail,
      from_display_name: profiles[currentUser.email]?.display_name || currentUser.email,
      to_display_name: recipientProfile?.display_name || recipientEmail,
      offer_item_type: offerType,
      offer_nft_id: offerType === 'nft' ? offerNFT?.id : undefined,
      offer_nft_name: offerType === 'nft' ? offerNFT?.nft_name : undefined,
      offer_nft_image: offerType === 'nft' ? offerNFT?.nft_image : undefined,
      offer_nft_collection: offerType === 'nft' ? offerNFT?.collection : undefined,
      offer_username: offerType === 'username' ? offerUsername?.username : undefined,
      request_item_type: requestType,
      request_nft_id: requestType === 'nft' ? requestNFTId : undefined,
      request_nft_name: requestType === 'nft' ? requestNFTName : undefined,
      request_nft_image: requestType === 'nft' ? requestNFTImage : undefined,
      request_nft_collection: requestType === 'nft' ? requestNFTCollection : undefined,
      request_username: requestType === 'username' ? requestUsername : undefined,
      request_currency_amount: requestType === 'currency' ? parseFloat(requestAmount) : undefined,
      request_currency_symbol: requestType === 'currency' ? requestSymbol : undefined,
      message: message || undefined,
      status: 'pending',
    };
    await db.entities.TradeOffer.create(payload);
    setLoading(false);
    onCreated();
  };

  return (
    <div className="fixed inset-0 bg-black/70 flex items-end md:items-center justify-center z-50 p-4">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <h2 className="text-white font-semibold">New Trade Offer</h2>
          <button onClick={onClose} className="text-slate-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>

        <div className="p-4 space-y-4">
          {/* Step indicators */}
          <div className="flex items-center gap-2 text-xs text-slate-500">
            {['Recipient', 'Your Offer', 'You Want'].map((s, i) => (
              <React.Fragment key={s}>
                <span className={`px-2 py-1 rounded ${step === i + 1 ? 'bg-blue-600 text-white' : step > i + 1 ? 'text-green-400' : ''}`}>{i + 1}. {s}</span>
                {i < 2 && <span>→</span>}
              </React.Fragment>
            ))}
          </div>

          {/* Step 1: Pick recipient */}
          {step === 1 && (
            <div>
              <p className="text-sm text-slate-300 mb-2">Who do you want to trade with?</p>
              <input
                value={search}
                onChange={e => setSearch(e.target.value)}
                placeholder="Search users..."
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-sm mb-2 outline-none focus:border-blue-500"
              />
              <div className="space-y-1 max-h-60 overflow-y-auto">
                {filtered.map(p => (
                  <button
                    key={p.email}
                    onClick={() => selectRecipient(p.email)}
                    className="w-full flex items-center gap-3 p-2 rounded-lg hover:bg-slate-800 transition-colors text-left"
                  >
                    <div className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center text-white text-xs font-bold">
                      {(p.display_name || p.email)[0]?.toUpperCase()}
                    </div>
                    <div>
                      <p className="text-white text-sm font-medium">{p.display_name || p.email}</p>
                      <p className="text-slate-500 text-xs">{p.email}</p>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Step 2: What you offer */}
          {step === 2 && (
            <div>
              <p className="text-sm text-slate-300 mb-3">What are you offering?</p>
              <div className="flex gap-2 mb-3">
                <button onClick={() => setOfferType('nft')} className={`flex-1 py-2 rounded-lg text-sm border transition-colors ${offerType === 'nft' ? 'border-blue-500 bg-blue-500/10 text-blue-400' : 'border-slate-700 text-slate-400'}`}>
                  <Package className="w-4 h-4 inline mr-1" />NFT
                </button>
                <button onClick={() => setOfferType('username')} className={`flex-1 py-2 rounded-lg text-sm border transition-colors ${offerType === 'username' ? 'border-blue-500 bg-blue-500/10 text-blue-400' : 'border-slate-700 text-slate-400'}`}>
                  <AtSign className="w-4 h-4 inline mr-1" />Username
                </button>
              </div>

              {offerType === 'nft' && (
                <div className="space-y-1 max-h-56 overflow-y-auto">
                  {myNFTs.length === 0 ? <p className="text-slate-500 text-sm text-center py-4">No NFTs in inventory</p> : myNFTs.map(nft => (
                    <button
                      key={nft.id}
                      onClick={() => { setOfferNFT(nft); setStep(3); }}
                      className={`w-full flex items-center gap-3 p-2 rounded-lg hover:bg-slate-800 border transition-colors ${offerNFT?.id === nft.id ? 'border-blue-500 bg-blue-500/10' : 'border-transparent'}`}
                    >
                      {nft.nft_image ? <img src={nft.nft_image} className="w-10 h-10 rounded-lg object-cover" /> : <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center"><Package className="w-4 h-4 text-slate-400" /></div>}
                      <div className="text-left">
                        <p className="text-white text-sm font-medium">{nft.nft_name}</p>
                        <p className="text-slate-400 text-xs">{nft.collection}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {offerType === 'username' && (
                <div className="space-y-1 max-h-56 overflow-y-auto">
                  {myUsernames.length === 0 ? <p className="text-slate-500 text-sm text-center py-4">No usernames owned</p> : myUsernames.map(u => (
                    <button
                      key={u.id}
                      onClick={() => { setOfferUsername(u); setStep(3); }}
                      className={`w-full flex items-center gap-3 p-2 rounded-lg hover:bg-slate-800 border transition-colors ${offerUsername?.id === u.id ? 'border-blue-500 bg-blue-500/10' : 'border-transparent'}`}
                    >
                      <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center"><AtSign className="w-4 h-4 text-blue-400" /></div>
                      <p className="text-white text-sm font-medium">@{u.username}</p>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Step 3: What you want */}
          {step === 3 && (
            <div>
              <p className="text-sm text-slate-300 mb-3">What do you want in return?</p>
              <div className="flex gap-2 mb-3">
                {['nft', 'username', 'currency'].map(t => (
                  <button key={t} onClick={() => setRequestType(t)} className={`flex-1 py-2 rounded-lg text-xs border transition-colors ${requestType === t ? 'border-blue-500 bg-blue-500/10 text-blue-400' : 'border-slate-700 text-slate-400'}`}>
                    {t === 'nft' && <><Package className="w-3 h-3 inline mr-1" />NFT</>}
                    {t === 'username' && <><AtSign className="w-3 h-3 inline mr-1" />Username</>}
                    {t === 'currency' && <><DollarSign className="w-3 h-3 inline mr-1" />Currency</>}
                  </button>
                ))}
              </div>

              {requestType === 'nft' && (
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  {recipientNFTs.length === 0 ? <p className="text-slate-500 text-sm text-center py-4">This user has no NFTs</p> : recipientNFTs.map(nft => (
                    <button
                      key={nft.id}
                      onClick={() => { setRequestNFTId(nft.id); setRequestNFTName(nft.nft_name); setRequestNFTImage(nft.nft_image); setRequestNFTCollection(nft.collection); }}
                      className={`w-full flex items-center gap-3 p-2 rounded-lg hover:bg-slate-800 border transition-colors ${requestNFTId === nft.id ? 'border-blue-500 bg-blue-500/10' : 'border-transparent'}`}
                    >
                      {nft.nft_image ? <img src={nft.nft_image} className="w-10 h-10 rounded-lg object-cover" /> : <div className="w-10 h-10 rounded-lg bg-slate-700 flex items-center justify-center"><Package className="w-4 h-4 text-slate-400" /></div>}
                      <div className="text-left">
                        <p className="text-white text-sm font-medium">{nft.nft_name}</p>
                        <p className="text-slate-400 text-xs">{nft.collection}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}

              {requestType === 'username' && (
                <div className="space-y-1 max-h-48 overflow-y-auto">
                  {recipientUsernames.length === 0 ? <p className="text-slate-500 text-sm text-center py-4">This user has no usernames</p> : recipientUsernames.map(u => (
                    <button
                      key={u.id}
                      onClick={() => setRequestUsername(u.username)}
                      className={`w-full flex items-center gap-3 p-2 rounded-lg hover:bg-slate-800 border transition-colors ${requestUsername === u.username ? 'border-blue-500 bg-blue-500/10' : 'border-transparent'}`}
                    >
                      <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center"><AtSign className="w-4 h-4 text-blue-400" /></div>
                      <p className="text-white text-sm font-medium">@{u.username}</p>
                    </button>
                  ))}
                </div>
              )}

              {requestType === 'currency' && (
                <div className="flex gap-2">
                  <input
                    type="number"
                    value={requestAmount}
                    onChange={e => setRequestAmount(e.target.value)}
                    placeholder="Amount"
                    className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-blue-500"
                  />
                  <select
                    value={requestSymbol}
                    onChange={e => setRequestSymbol(e.target.value)}
                    className="bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-sm outline-none"
                  >
                    <option>USD</option>
                    <option>TON</option>
                    <option>ETH</option>
                  </select>
                </div>
              )}

              <textarea
                value={message}
                onChange={e => setMessage(e.target.value)}
                placeholder="Add a message (optional)..."
                className="w-full mt-3 bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-sm outline-none focus:border-blue-500 resize-none h-16"
              />
            </div>
          )}

          {/* Navigation buttons */}
          <div className="flex gap-2 pt-2">
            {step > 1 && (
              <Button variant="outline" onClick={() => setStep(s => s - 1)} className="border-slate-700 text-slate-300 hover:bg-slate-800">
                Back
              </Button>
            )}
            {step === 3 && (
              <Button
                onClick={handleSubmit}
                disabled={loading || (
                  (requestType === 'nft' && !requestNFTId) ||
                  (requestType === 'username' && !requestUsername) ||
                  (requestType === 'currency' && !requestAmount)
                )}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                {loading ? 'Sending...' : 'Send Trade Offer'}
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}