const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';

import Avatar from './Avatar';
import StatusDot from './StatusDot';
import NFTCard from './NFTCard';
import UsernameDetailsModal from '../shop/UsernameDetailsModal';
import BadgeIcon from '../shared/BadgeIcon';
import { BADGE_CONFIG } from '../shared/badgeConfig';
import { Button } from '@/components/ui/button';
import { X, AtSign, Calendar, Wallet } from 'lucide-react';
import moment from 'moment';

export default function ProfilePanel({ profile, onClose, onMessage }) {
  const [selectedUsername, setSelectedUsername] = useState(null);

  const { data: ownedUsernames = [] } = useQuery({
    queryKey: ['panelUsernames', profile?.email],
    queryFn: async () => {
      const all = await db.entities.CollectibleUsername.filter({ owner_email: profile.email });
      return all.filter(u => u.visible_on_profile !== false);
    },
    enabled: !!profile?.email,
  });

  if (!profile) return null;

  return (
    <>
      <div className="w-80 border-l border-slate-800 bg-slate-950/60 backdrop-blur-xl flex flex-col h-full overflow-y-auto">
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <h3 className="font-semibold text-sm text-slate-100">Profile</h3>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="flex flex-col items-center pt-8 pb-4 px-4">
          <Avatar src={profile.profile_picture} name={profile.display_name || profile.email} status={profile.status} size="2xl" />
          <div className="flex items-center gap-2 mt-4 flex-wrap justify-center">
            <h2 className="text-lg font-bold text-slate-100">{profile.display_name || profile.email}</h2>
            {profile.badges?.filter(b => BADGE_CONFIG[b]?.inline).map(b => (
              <BadgeIcon key={b} badgeKey={b} cfg={BADGE_CONFIG[b]} size={5} />
            ))}
            {ownedUsernames.length > 0 && (
              <span className="text-xs font-bold px-1.5 py-0.5 rounded"
                style={{ color: '#FFD700', textShadow: '0 0 8px #FFD700, 0 0 16px #FFA500' }}>
                OWNER
              </span>
            )}
          </div>
          {profile.username && (
            <div className="flex items-center gap-1 mt-1">
              <AtSign className="w-3 h-3 text-blue-400" />
              <span className="text-sm text-blue-400">{profile.username}</span>
            </div>
          )}
          {ownedUsernames.length > 0 && (
            <div className="flex flex-wrap items-center justify-center gap-1 mt-1.5">
              <span className="text-[11px] text-slate-500">also known as</span>
              {ownedUsernames.map(u => (
                <button
                  key={u.id}
                  onClick={() => setSelectedUsername(u)}
                  className="text-[11px] text-blue-400 hover:underline"
                >
                  @{u.username}
                </button>
              ))}
            </div>
          )}
          <div className="flex items-center gap-1.5 mt-2">
            <StatusDot status={profile.status || 'offline'} size="xs" />
            <span className="text-xs text-slate-400 capitalize">{profile.status || 'offline'}</span>
          </div>
        </div>

        {profile.badges?.length > 0 && (
          <div className="px-4 pb-3 flex flex-wrap gap-2 justify-center">
            {profile.badges.map((badge) => (
              <BadgeIcon key={badge} badgeKey={badge} cfg={BADGE_CONFIG[badge]} size={7} />
            ))}
          </div>
        )}

        {profile.bio && (
          <div className="px-4 pb-4">
            <p className="text-sm text-slate-400 text-center italic">"{profile.bio}"</p>
          </div>
        )}

        <div className="px-4 pb-4 space-y-2">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <Calendar className="w-3.5 h-3.5" />
            <span>Joined {moment(profile.created_date).format('MMMM YYYY')}</span>
          </div>
          {profile.wallet_address && (
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Wallet className="w-3.5 h-3.5" />
              <span className="truncate">{profile.wallet_address.slice(0, 6)}...{profile.wallet_address.slice(-4)}</span>
            </div>
          )}
        </div>

        {profile.nfts?.length > 0 && (
          <div className="px-4 pb-4">
            <h4 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">NFT Collection ({profile.nfts.length})</h4>
            <div className="grid grid-cols-2 gap-2">
              {profile.nfts.map((nft, i) => (
                <NFTCard key={i} nft={nft} />
              ))}
            </div>
          </div>
        )}

        {onMessage && (
          <div className="px-4 pb-4 mt-auto">
            <Button onClick={onMessage} className="w-full bg-blue-600 hover:bg-blue-500">Send Message</Button>
          </div>
        )}
      </div>

      <UsernameDetailsModal
        username={selectedUsername}
        owner={profile}
        open={!!selectedUsername}
        onClose={() => setSelectedUsername(null)}
      />
    </>
  );
}