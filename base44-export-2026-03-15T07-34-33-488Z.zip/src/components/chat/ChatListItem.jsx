import React from 'react';
import { cn } from '@/lib/utils';
import Avatar from './Avatar';
import moment from 'moment';

export default function ChatListItem({ chat, currentUserEmail, profiles, isActive, onClick }) {
  const isGroup = chat.type === 'group';
  const otherEmail = !isGroup
    ? chat.participants?.find(p => p !== currentUserEmail)
    : null;
  const otherProfile = otherEmail ? profiles[otherEmail] : null;

  const chatName = isGroup
    ? chat.name || 'Group Chat'
    : otherProfile?.display_name || otherEmail || 'Unknown';

  const chatAvatar = isGroup
    ? chat.avatar_url
    : otherProfile?.profile_picture;

  const chatStatus = isGroup ? null : otherProfile?.status || 'offline';

  const timeLabel = chat.last_message_time
    ? moment(chat.last_message_time).fromNow(true)
    : '';

  return (
    <button
      onClick={onClick}
      className={cn(
        'w-full flex items-center gap-3 px-4 py-3 transition-all duration-150 text-left group',
        'hover:bg-slate-800/60',
        isActive && 'bg-slate-800/80 border-l-2 border-blue-500'
      )}
    >
      <Avatar
        src={chatAvatar}
        name={chatName}
        status={chatStatus}
        size="md"
      />
      <div className="flex-1 min-w-0">
        <div className="flex items-center justify-between">
          <span className="font-medium text-sm text-slate-100 truncate">
            {chatName}
          </span>
          {timeLabel && (
            <span className="text-[10px] text-slate-500 ml-2 shrink-0">
              {timeLabel}
            </span>
          )}
        </div>
        {chat.last_message && (
          <p className="text-xs text-slate-400 truncate mt-0.5">
            {chat.last_message}
          </p>
        )}
      </div>
    </button>
  );
}