import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Search, Users, User, X } from 'lucide-react';
import Avatar from './Avatar';

export default function NewChatModal({ open, onClose, profiles, currentUserEmail, onCreateChat }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [groupName, setGroupName] = useState('');
  const [selectedMembers, setSelectedMembers] = useState([]);

  const allProfiles = Object.values(profiles).filter(p => p.email !== currentUserEmail);

  const filtered = allProfiles.filter(p =>
    (p.display_name || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (p.username || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
    (p.email || '').toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleDirectChat = (profile) => {
    onCreateChat({ type: 'direct', participants: [currentUserEmail, profile.email] });
    onClose();
  };

  const toggleMember = (email) => {
    setSelectedMembers(prev =>
      prev.includes(email) ? prev.filter(e => e !== email) : [...prev, email]
    );
  };

  const handleCreateGroup = () => {
    if (selectedMembers.length < 1 || !groupName.trim()) return;
    onCreateChat({
      type: 'group',
      name: groupName.trim(),
      participants: [currentUserEmail, ...selectedMembers],
    });
    onClose();
    setGroupName('');
    setSelectedMembers([]);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-800 text-slate-100 max-w-md">
        <DialogHeader>
          <DialogTitle className="text-slate-100">New Chat</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="direct" className="mt-2">
          <TabsList className="bg-slate-800 w-full">
            <TabsTrigger value="direct" className="flex-1 data-[state=active]:bg-blue-600">
              <User className="w-4 h-4 mr-2" /> Direct
            </TabsTrigger>
            <TabsTrigger value="group" className="flex-1 data-[state=active]:bg-blue-600">
              <Users className="w-4 h-4 mr-2" /> Group
            </TabsTrigger>
          </TabsList>

          <div className="mt-3">
            <div className="relative">
              <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <Input
                placeholder="Search by name or username..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500"
              />
            </div>
          </div>

          <TabsContent value="direct" className="mt-3 space-y-1 max-h-64 overflow-y-auto">
            {filtered.map(p => (
              <button
                key={p.email}
                onClick={() => handleDirectChat(p)}
                className="w-full flex items-center gap-3 p-2.5 rounded-lg hover:bg-slate-800 transition-colors"
              >
                <Avatar src={p.profile_picture} name={p.display_name || p.email} status={p.status} size="sm" />
                <div className="text-left">
                  <p className="text-sm font-medium">{p.display_name || p.email}</p>
                  {p.username && <p className="text-xs text-slate-500">@{p.username}</p>}
                </div>
              </button>
            ))}
            {filtered.length === 0 && (
              <p className="text-sm text-slate-500 text-center py-8">No users found</p>
            )}
          </TabsContent>

          <TabsContent value="group" className="mt-3 space-y-3">
            <Input
              placeholder="Group name"
              value={groupName}
              onChange={(e) => setGroupName(e.target.value)}
              className="bg-slate-800 border-slate-700 text-slate-100 placeholder:text-slate-500"
            />

            {selectedMembers.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {selectedMembers.map(email => {
                  const p = profiles[email];
                  return (
                    <span key={email} className="flex items-center gap-1 bg-blue-600/20 text-blue-300 text-xs px-2 py-1 rounded-full">
                      {p?.display_name || email}
                      <button onClick={() => toggleMember(email)}>
                        <X className="w-3 h-3" />
                      </button>
                    </span>
                  );
                })}
              </div>
            )}

            <div className="max-h-48 overflow-y-auto space-y-1">
              {filtered.map(p => (
                <button
                  key={p.email}
                  onClick={() => toggleMember(p.email)}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-lg transition-colors ${
                    selectedMembers.includes(p.email) ? 'bg-blue-600/10 border border-blue-600/30' : 'hover:bg-slate-800'
                  }`}
                >
                  <Avatar src={p.profile_picture} name={p.display_name || p.email} size="sm" />
                  <div className="text-left flex-1">
                    <p className="text-sm font-medium">{p.display_name || p.email}</p>
                    {p.username && <p className="text-xs text-slate-500">@{p.username}</p>}
                  </div>
                  {selectedMembers.includes(p.email) && (
                    <div className="w-5 h-5 bg-blue-600 rounded-full flex items-center justify-center">
                      <span className="text-white text-xs">✓</span>
                    </div>
                  )}
                </button>
              ))}
            </div>

            <Button
              onClick={handleCreateGroup}
              disabled={selectedMembers.length < 1 || !groupName.trim()}
              className="w-full bg-blue-600 hover:bg-blue-500"
            >
              Create Group ({selectedMembers.length} members)
            </Button>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}