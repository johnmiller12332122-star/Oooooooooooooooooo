import React from 'react';
import { MessageSquare } from 'lucide-react';

export default function EmptyChat() {
  return (
    <div className="flex-1 flex flex-col items-center justify-center bg-slate-950/30">
      <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-blue-600/10 to-purple-600/10 border border-slate-800 flex items-center justify-center mb-6">
        <MessageSquare className="w-8 h-8 text-blue-500/50" />
      </div>
      <h2 className="text-xl font-semibold text-slate-300 mb-2">Welcome to Chat</h2>
      <p className="text-sm text-slate-500 text-center max-w-xs">
        Select a conversation or start a new chat to begin messaging
      </p>
    </div>
  );
}