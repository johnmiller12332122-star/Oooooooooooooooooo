import React from 'react';
import { cn } from '@/lib/utils';

export default function StatusDot({ status = 'offline', size = 'sm' }) {
  const sizeClasses = {
    xs: 'w-2 h-2',
    sm: 'w-2.5 h-2.5',
    md: 'w-3 h-3',
    lg: 'w-3.5 h-3.5',
  };

  const statusColors = {
    online: 'bg-emerald-500 shadow-emerald-500/50',
    away: 'bg-amber-500 shadow-amber-500/50',
    offline: 'bg-slate-400 shadow-slate-400/50',
  };

  return (
    <span
      className={cn(
        'rounded-full ring-2 ring-slate-900 shadow-lg inline-block',
        sizeClasses[size],
        statusColors[status]
      )}
    />
  );
}