import React, { useState } from 'react';
import { cn } from '@/lib/utils';
import Avatar from './Avatar';
import moment from 'moment';
import { FileText, Download, Smile } from 'lucide-react';

const EMOJIS = ['👍', '❤️', '😂', '😮', '😢', '🔥'];

export default function MessageBubble({ message, isOwn, showAvatar, senderProfile, currentUserEmail, onReact }) {
  const [showPicker, setShowPicker] = useState(false);
  const time = moment(message.created_date).format('h:mm A');
  const reactions = message.reactions || {};
  const reactionEntries = Object.entries(reactions).filter(([, users]) => Array.isArray(users) && users.length > 0);

  const handleReact = (emoji) => {
    onReact?.(message.id, emoji);
    setShowPicker(false);
  };

  return (
    <div className={cn('flex gap-2 message-enter', isOwn ? 'flex-row-reverse' : 'flex-row')}>
      {!isOwn && showAvatar ? (
        <Avatar src={senderProfile?.profile_picture} name={message.sender_name || message.sender_email} size="sm" className="mt-1" />
      ) : (!isOwn && <div className="w-8 shrink-0" />)}

      <div className={cn('max-w-[70%] group', isOwn ? 'items-end' : 'items-start')}>
        {!isOwn && showAvatar && (
          <p className="text-[10px] text-slate-500 mb-1 ml-1">{senderProfile?.display_name || message.sender_name}</p>
        )}

        <div className={cn('flex items-end gap-1.5', isOwn ? 'flex-row-reverse' : 'flex-row')}>
          <div className={cn('rounded-2xl px-4 py-2.5 relative', isOwn ? 'bg-blue-600 text-white rounded-tr-sm' : 'bg-slate-800 text-slate-100 rounded-tl-sm')}>
            {message.type === 'image' && message.file_url && (
              <img src={message.file_url} alt="Shared image" className="rounded-lg max-w-full mb-2 cursor-pointer hover:opacity-90 transition-opacity" onClick={() => window.open(message.file_url, '_blank')} />
            )}
            {message.type === 'file' && message.file_url && (
              <a href={message.file_url} target="_blank" rel="noopener noreferrer" className={cn('flex items-center gap-2 p-2 rounded-lg mb-2 transition-colors', isOwn ? 'bg-blue-700/50 hover:bg-blue-700/70' : 'bg-slate-700/50 hover:bg-slate-700/70')}>
                <FileText className="w-5 h-5 shrink-0" />
                <span className="text-sm truncate flex-1">{message.file_name || 'File'}</span>
                <Download className="w-4 h-4 shrink-0 opacity-60" />
              </a>
            )}
            {message.content && (
              <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{message.content}</p>
            )}
            <span className={cn('text-[10px] mt-1 block', isOwn ? 'text-blue-200/70 text-right' : 'text-slate-500 text-right')}>{time}</span>
          </div>

          {/* Reaction trigger */}
          <div className="relative shrink-0 mb-1">
            <button
              onClick={() => setShowPicker(!showPicker)}
              className="opacity-0 group-hover:opacity-100 transition-opacity p-1 rounded-full hover:bg-slate-700 text-slate-500 hover:text-slate-300"
            >
              <Smile className="w-4 h-4" />
            </button>
            {showPicker && (
              <div className={cn('absolute bottom-8 z-50 bg-slate-800 border border-slate-700 rounded-xl p-1.5 flex gap-0.5 shadow-xl', isOwn ? 'right-0' : 'left-0')}>
                {EMOJIS.map(emoji => (
                  <button key={emoji} onClick={() => handleReact(emoji)} className="text-lg hover:scale-125 transition-transform p-1 rounded hover:bg-slate-700">
                    {emoji}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Reactions display */}
        {reactionEntries.length > 0 && (
          <div className={cn('flex flex-wrap gap-1 mt-1', isOwn ? 'justify-end' : 'justify-start')}>
            {reactionEntries.map(([emoji, users]) => (
              <button
                key={emoji}
                onClick={() => handleReact(emoji)}
                className={cn(
                  'flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border transition-colors',
                  users.includes(currentUserEmail)
                    ? 'bg-blue-500/20 border-blue-500/40 text-blue-300'
                    : 'bg-slate-800 border-slate-700 text-slate-300 hover:bg-slate-700'
                )}
              >
                <span>{emoji}</span>
                <span>{users.length}</span>
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}