import React from 'react';
import { cn } from '@/lib/utils';
import { ExternalLink } from 'lucide-react';

export default function NFTCard({ nft, compact = false }) {
  return (
    <div
      className={cn(
        'group relative rounded-xl overflow-hidden bg-slate-800 border border-slate-700/50',
        'hover:border-blue-500/30 hover:shadow-lg hover:shadow-blue-500/5 transition-all duration-300',
        compact ? 'w-20 h-20' : ''
      )}
    >
      {nft.image_url ? (
        <img
          src={nft.image_url}
          alt={nft.name}
          className={cn(
            'w-full object-cover',
            compact ? 'h-20' : 'aspect-square'
          )}
        />
      ) : (
        <div className={cn(
          'w-full bg-gradient-to-br from-purple-600/20 to-blue-600/20 flex items-center justify-center',
          compact ? 'h-20' : 'aspect-square'
        )}>
          <span className="text-2xl">🖼</span>
        </div>
      )}

      {!compact && (
        <div className="p-3">
          <p className="text-sm font-medium text-slate-100 truncate">{nft.name}</p>
          <p className="text-xs text-slate-500 truncate mt-0.5">{nft.collection}</p>
          {nft.token_id && (
            <p className="text-[10px] text-slate-600 mt-1">#{nft.token_id}</p>
          )}
        </div>
      )}

      <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
        <ExternalLink className="w-5 h-5 text-white" />
      </div>
    </div>
  );
}