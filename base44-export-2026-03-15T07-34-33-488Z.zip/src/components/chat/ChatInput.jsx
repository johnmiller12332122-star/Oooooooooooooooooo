const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Send, Paperclip, Image, X } from 'lucide-react';

export default function ChatInput({ onSend, disabled, inputRef: externalRef }) {
  const [text, setText] = useState('');
  const [attachment, setAttachment] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const fileRef = useRef(null);
  const internalRef = useRef(null);
  const textareaRef = externalRef || internalRef;

  const uploadFile = async (file) => {
    setUploading(true);
    const { file_url } = await db.integrations.Core.UploadFile({ file });
    const isImage = file.type.startsWith('image/');
    setAttachment({ url: file_url, name: file.name, type: isImage ? 'image' : 'file' });
    setUploading(false);
  };

  const handleDrop = async (e) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) uploadFile(file);
  };

  const handleSend = () => {
    if ((!text.trim() && !attachment) || disabled) return;
    onSend({
      content: text.trim(),
      type: attachment?.type || 'text',
      file_url: attachment?.url,
      file_name: attachment?.name,
    });
    setText('');
    setAttachment(null);
  };

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const handlePaste = async (e) => {
    const items = e.clipboardData?.items;
    if (!items) return;
    for (const item of items) {
      if (item.type.startsWith('image/')) {
        e.preventDefault();
        const file = item.getAsFile();
        if (file) await uploadFile(file);
        return;
      }
    }
  };

  const handleFileSelect = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await uploadFile(file);
    if (fileRef.current) fileRef.current.value = '';
  };

  return (
    <div
      className={`border-t border-slate-800 bg-slate-950/80 backdrop-blur-xl p-3 transition-colors ${isDragging ? 'bg-blue-950/40 border-blue-500/50' : ''}`}
      onDrop={handleDrop}
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
    >
      {isDragging && (
        <div className="absolute inset-0 flex items-center justify-center bg-blue-950/60 rounded-b-lg z-10 pointer-events-none">
          <p className="text-blue-300 font-medium text-sm">Drop file to attach</p>
        </div>
      )}
      {attachment && (
        <div className="flex items-center gap-2 mb-2 px-2 py-1.5 bg-slate-800/60 rounded-lg">
          {attachment.type === 'image' ? (
            <Image className="w-4 h-4 text-blue-400" />
          ) : (
            <Paperclip className="w-4 h-4 text-blue-400" />
          )}
          <span className="text-xs text-slate-300 truncate flex-1">{attachment.name}</span>
          <button onClick={() => setAttachment(null)}>
            <X className="w-3.5 h-3.5 text-slate-500 hover:text-slate-300" />
          </button>
        </div>
      )}

      <div className="flex items-end gap-2">
        <input
          type="file"
          ref={fileRef}
          onChange={handleFileSelect}
          className="hidden"
        />
        <Button
          variant="ghost"
          size="icon"
          className="text-slate-400 hover:text-slate-200 hover:bg-slate-800 shrink-0 h-10 w-10"
          onClick={() => fileRef.current?.click()}
          disabled={uploading}
        >
          <Paperclip className="w-5 h-5" />
        </Button>

        <div className="flex-1 relative">
          <textarea
            ref={textareaRef}
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={handleKeyDown}
            onPaste={handlePaste}
            placeholder={uploading ? 'Uploading...' : 'Type a message...'}
            disabled={uploading || disabled}
            rows={1}
            className="w-full bg-slate-800/60 border border-slate-700/50 rounded-xl px-4 py-2.5 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-blue-500/50 focus:ring-1 focus:ring-blue-500/20 resize-none max-h-32"
            style={{ minHeight: '42px' }}
          />
        </div>

        <Button
          size="icon"
          className="bg-blue-600 hover:bg-blue-500 text-white shrink-0 h-10 w-10 rounded-xl transition-all duration-200 disabled:opacity-30"
          onClick={handleSend}
          disabled={(!text.trim() && !attachment) || uploading || disabled}
        >
          <Send className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}