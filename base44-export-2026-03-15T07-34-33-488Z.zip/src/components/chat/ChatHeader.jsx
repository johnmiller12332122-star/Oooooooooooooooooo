import React from 'react';
import Avatar from './Avatar';
import StatusDot from './StatusDot';
import { Button } from '@/components/ui/button';
import { MoreVertical, ArrowLeft } from 'lucide-react';
import moment from 'moment';

export default function ChatHeader({ chat, profiles, currentUserEmail, onProfileClick, onBack }) {
  const isGroup = chat?.type === 'group';
  const otherEmail = !isGroup
    ? chat?.participants?.find(p => p !== currentUserEmail)
    : null;
  const otherProfile = otherEmail ? profiles[otherEmail] : null;

  const chatName = isGroup
    ? chat?.name || 'Group Chat'
    : otherProfile?.display_name || otherEmail || 'Unknown';

  const chatAvatar = isGroup ? chat?.avatar_url : otherProfile?.profile_picture;
  const chatStatus = isGroup ? null : otherProfile?.status || 'offline';

  const memberCount = isGroup ? chat?.participants?.length : null;

  return (
    <div className="h-16 border-b border-slate-800 bg-slate-950/60 backdrop-blur-xl flex items-center px-4 gap-3">
      {onBack && (
        <Button
          variant="ghost"
          size="icon"
          onClick={onBack}
          className="text-slate-400 hover:text-slate-200 hover:bg-slate-800 h-8 w-8 md:hidden"
        >
          <ArrowLeft className="w-4 h-4" />
        </Button>
      )}

      <button
        onClick={() => !isGroup && otherProfile && onProfileClick?.(otherProfile)}
        className="flex items-center gap-3 flex-1 min-w-0"
      >
        <Avatar src={chatAvatar} name={chatName} status={chatStatus} size="md" />
        <div className="text-left min-w-0">
          <h2 className="text-sm font-semibold text-slate-100 truncate">{chatName}</h2>
          <p className="text-xs text-slate-500">
            {isGroup
              ? `${memberCount} members`
              : chatStatus === 'online'
                ? 'Online'
                : otherProfile?.last_seen
                  ? `Last seen ${moment(otherProfile.last_seen).fromNow()}`
                  : 'Offline'
            }
          </p>
        </div>
      </button>

      <div className="flex items-center gap-1">
        <Button
          variant="ghost"
          size="icon"
          className="text-slate-400 hover:text-slate-200 hover:bg-slate-800 h-8 w-8"
          onClick={() => {
            if (!isGroup && otherProfile) onProfileClick?.(otherProfile);
          }}
        >
          <MoreVertical className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
}