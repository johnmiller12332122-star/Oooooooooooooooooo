import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Search, Plus, Settings, User, MessageSquare } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import Avatar from './Avatar';
import ChatListItem from './ChatListItem';

export default function Sidebar({
  chats,
  profiles,
  currentUserEmail,
  currentUserProfile,
  activeChatId,
  onChatSelect,
  onNewChat,
}) {
  const [search, setSearch] = useState('');

  const filteredChats = chats.filter(chat => {
    if (!search.trim()) return true;
    const q = search.toLowerCase();
    if (chat.name?.toLowerCase().includes(q)) return true;
    const otherEmail = chat.participants?.find(p => p !== currentUserEmail);
    const otherProfile = otherEmail ? profiles[otherEmail] : null;
    return (
      otherProfile?.display_name?.toLowerCase().includes(q) ||
      otherProfile?.username?.toLowerCase().includes(q) ||
      otherEmail?.toLowerCase().includes(q)
    );
  });

  return (
    <div className="w-80 border-r border-slate-800 bg-slate-950/80 backdrop-blur-xl flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-blue-500" />
            <h1 className="text-lg font-bold text-slate-100">Messages</h1>
          </div>
          <div className="flex items-center gap-1">
            <Button
              variant="ghost"
              size="icon"
              onClick={onNewChat}
              className="text-slate-400 hover:text-slate-200 hover:bg-slate-800 h-8 w-8"
            >
              <Plus className="w-4 h-4" />
            </Button>
            <Link to={createPageUrl('Settings')}>
              <Button
                variant="ghost"
                size="icon"
                className="text-slate-400 hover:text-slate-200 hover:bg-slate-800 h-8 w-8"
              >
                <Settings className="w-4 h-4" />
              </Button>
            </Link>
          </div>
        </div>

        <div className="relative">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <Input
            placeholder="Search chats..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 bg-slate-800/60 border-slate-700/50 text-slate-100 placeholder:text-slate-500 h-9 text-sm rounded-lg"
          />
        </div>
      </div>

      {/* Chat list */}
      <div className="flex-1 overflow-y-auto">
        {filteredChats.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-center px-6">
            <div className="w-12 h-12 rounded-full bg-slate-800 flex items-center justify-center mb-3">
              <MessageSquare className="w-5 h-5 text-slate-600" />
            </div>
            <p className="text-sm text-slate-500">No conversations yet</p>
            <p className="text-xs text-slate-600 mt-1">Start a new chat</p>
          </div>
        ) : (
          filteredChats.map(chat => (
            <ChatListItem
              key={chat.id}
              chat={chat}
              currentUserEmail={currentUserEmail}
              profiles={profiles}
              isActive={chat.id === activeChatId}
              onClick={() => onChatSelect(chat)}
            />
          ))
        )}
      </div>

      {/* Current user */}
      <div className="p-3 border-t border-slate-800">
        <Link to={createPageUrl('Profile')} className="flex items-center gap-3 p-2 rounded-lg hover:bg-slate-800 transition-colors">
          <Avatar
            src={currentUserProfile?.profile_picture}
            name={currentUserProfile?.display_name || currentUserEmail}
            status="online"
            size="sm"
          />
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium text-slate-200 truncate">
              {currentUserProfile?.display_name || currentUserEmail}
            </p>
            {currentUserProfile?.username && (
              <p className="text-xs text-slate-500">@{currentUserProfile.username}</p>
            )}
          </div>
        </Link>
      </div>
    </div>
  );
}