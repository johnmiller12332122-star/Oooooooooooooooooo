import React from 'react';
import { Dialog, DialogContent, DialogHeader } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, ExternalLink, Copy } from 'lucide-react';
import { toast } from 'sonner';

export default function NFTDetailsModal({ nft, open, onClose, owner, tokenId, totalSupply }) {
  if (!nft) return null;

  const details = [
    { label: 'Owner', value: owner?.display_name || owner?.email || 'Unknown' },
    { label: 'Collection', value: nft.collection },
    { label: 'Model', value: nft.name },
    { label: 'Symbol', value: nft.symbol || nft.collection?.substring(0, 4).toUpperCase() || 'NFT' },
    { label: 'Blockchain', value: 'TDN Blockchain (level 1)' },
    { label: 'Quantity', value: tokenId && totalSupply ? `${tokenId} of ${totalSupply}` : 'Limited Edition' },
    { label: 'Value', value: 'Visible on your profile (100%)' },
  ];

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-800 text-slate-100 max-w-md p-0 gap-0">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="relative h-56 bg-gradient-to-br from-blue-900/40 to-slate-900 flex items-center justify-center overflow-hidden">
          {nft.image_url || nft.nft_image ? (
            <img 
              src={nft.image_url || nft.nft_image} 
              alt={nft.name || nft.nft_name} 
              className="w-40 h-40 object-contain rounded-lg"
            />
          ) : (
            <div className="w-32 h-32 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center text-4xl font-bold shadow-2xl">
              {nft.name?.[0] || nft.nft_name?.[0] || '?'}
            </div>
          )}
        </div>

        <div className="p-6 space-y-4">
          <div className="text-center">
            <h2 className="text-2xl font-bold">{nft.name || nft.nft_name}</h2>
            <p className="text-sm text-cyan-400 mt-1">{nft.collection}</p>
          </div>

          <div className="space-y-2.5">
            {details.map((item, i) => (
              <div key={i} className="flex justify-between items-center py-2 border-b border-slate-800/50">
                <span className="text-sm text-slate-400">{item.label}</span>
                <span className="text-sm font-medium text-slate-200">{item.value}</span>
              </div>
            ))}
          </div>

          <div className="flex gap-3 pt-2">
            <Button
              onClick={() => toast.success('Link copied!')}
              variant="outline"
              className="flex-1 border-slate-700 hover:bg-slate-800"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy Link
            </Button>
            <Button className="flex-1 bg-cyan-600 hover:bg-cyan-500">
              <ExternalLink className="w-4 h-4 mr-2" />
              Learn More
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}