import React from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { X, CheckCircle, Sparkles } from 'lucide-react';

export default function PurchaseSuccessModal({ nft, open, onClose }) {
  if (!nft) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-800 text-slate-100 max-w-md p-0 gap-0">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="relative h-64 bg-gradient-to-br from-green-600/20 via-emerald-600/20 to-teal-600/20 flex flex-col items-center justify-center overflow-hidden">
          <div className="absolute inset-0 flex items-center justify-center opacity-10">
            <Sparkles className="w-64 h-64 text-green-400" />
          </div>
          
          <CheckCircle className="w-16 h-16 text-green-400 mb-4 relative z-10" />
          <h2 className="text-2xl font-bold relative z-10">Purchase Successful!</h2>
          <p className="text-slate-400 mt-2 relative z-10">Your NFT has been added to your inventory</p>
        </div>

        <div className="p-6 space-y-4">
          <div className="bg-slate-800/50 rounded-lg p-4 flex items-center gap-4">
            {nft.image_url && (
              <img src={nft.image_url} alt={nft.name} className="w-20 h-20 rounded-lg object-cover" />
            )}
            <div>
              <h3 className="font-bold text-lg">{nft.name}</h3>
              <p className="text-sm text-cyan-400">{nft.collection}</p>
              <p className="text-xs text-slate-500 mt-1">Token ID: #{nft.token_id}</p>
            </div>
          </div>

          <Button
            onClick={onClose}
            className="w-full bg-green-600 hover:bg-green-500"
          >
            View in Inventory
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}