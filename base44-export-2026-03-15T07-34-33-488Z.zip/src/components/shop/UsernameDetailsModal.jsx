import React from 'react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import Avatar from '../chat/Avatar';
import { X, Copy, ExternalLink, AtSign } from 'lucide-react';
import { toast } from 'sonner';
import moment from 'moment';

export default function UsernameDetailsModal({ username, open, onClose, owner }) {
  if (!username) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-800 text-slate-100 max-w-md p-0 gap-0">
        <button
          onClick={onClose}
          className="absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-slate-800/80 hover:bg-slate-700 flex items-center justify-center"
        >
          <X className="w-4 h-4" />
        </button>

        <div className="relative h-48 bg-gradient-to-br from-slate-800 to-slate-900 flex items-center justify-center">
          <div className="w-24 h-24 rounded-full bg-slate-700 flex items-center justify-center">
            <AtSign className="w-12 h-12 text-slate-400" />
          </div>
        </div>

        <div className="p-6 space-y-4">
          <div className="text-center">
            <h2 className="text-2xl font-bold">@{username.username}</h2>
            <p className="text-sm text-slate-400 mt-1">is a collectible username that belongs to</p>
          </div>

          <div className="flex items-center justify-center gap-3 py-3">
            <Avatar
              src={owner?.profile_picture}
              name={owner?.display_name || owner?.email}
              size="md"
            />
            <span className="font-semibold">{owner?.display_name || owner?.email}</span>
          </div>

          <div className="bg-slate-800/30 rounded-lg p-4 space-y-2 border border-slate-700/50">
            <div className="text-xs text-slate-400 text-center">
              This username was bought on {moment(username.claimed_date).format('MMMM DD, YYYY')} at
            </div>
            <div className="text-center py-3">
              <div className="flex items-center justify-center gap-2">
                <span className="text-3xl">💎</span>
                <span className="text-3xl font-bold text-emerald-400">
                  ${username.price_usd?.toFixed(2)}
                </span>
              </div>
              <div className="text-xs text-slate-500 mt-2">Current market value</div>
            </div>
          </div>

          <div className="flex gap-3">
            <Button
              onClick={() => toast.success('Link copied!')}
              variant="outline"
              className="flex-1 bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
            >
              <Copy className="w-4 h-4 mr-2" />
              Copy Link
            </Button>
            <Button className="flex-1 bg-blue-600 hover:bg-blue-500">
              <ExternalLink className="w-4 h-4 mr-2" />
              Learn More
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}