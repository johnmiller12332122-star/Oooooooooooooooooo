import React from 'react';
import { Button } from '@/components/ui/button';
import { ShoppingCart, X, Trash2, Loader2 } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export default function CartDrawer({ cart, onRemove, onCheckout, isCheckingOut, open, onClose }) {
  const total = cart.reduce((sum, item) => sum + item.price_usd, 0);

  return (
    <>
      {/* Overlay */}
      {open && <div className="fixed inset-0 bg-black/40 z-40" onClick={onClose} />}

      {/* Drawer */}
      <div className={`fixed top-0 right-0 h-full w-80 bg-slate-900 border-l border-slate-800 z-50 flex flex-col transition-transform duration-300 ${open ? 'translate-x-0' : 'translate-x-full'}`}>
        <div className="flex items-center justify-between p-4 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShoppingCart className="w-5 h-5 text-blue-400" />
            <h2 className="font-bold">Cart ({cart.length})</h2>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.length === 0 ? (
            <p className="text-slate-500 text-center py-12">Your cart is empty</p>
          ) : (
            cart.map((item, i) => (
              <div key={i} className="flex items-center gap-3 bg-slate-800/50 rounded-lg p-3">
                <div className="w-12 h-12 rounded-lg overflow-hidden bg-gradient-to-br from-blue-900/30 to-purple-900/30 flex items-center justify-center shrink-0">
                  {item.image_url ? (
                    <img src={item.image_url} alt={item.name} className="w-full h-full object-contain p-1" />
                  ) : (
                    <span className="text-lg">🎨</span>
                  )}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-medium text-sm truncate">{item.name}</p>
                  <p className="text-xs text-cyan-400">{item.collection}</p>
                  <p className="text-xs text-green-400 font-bold mt-0.5">
                    {item.currency === 'TON' ? `${item.price_usd} 💎 TON` : `$${item.price_usd}`}
                  </p>
                </div>
                <button onClick={() => onRemove(i)} className="text-slate-500 hover:text-red-400 transition-colors">
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {cart.length > 0 && (
          <div className="p-4 border-t border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-400">Total ({cart.length} items)</span>
              <span className="font-bold text-green-400">${total.toFixed(2)}</span>
            </div>
            <Button
              onClick={onCheckout}
              disabled={isCheckingOut}
              className="w-full bg-blue-600 hover:bg-blue-500"
            >
              {isCheckingOut ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              Checkout All
            </Button>
          </div>
        )}
      </div>
    </>
  );
}