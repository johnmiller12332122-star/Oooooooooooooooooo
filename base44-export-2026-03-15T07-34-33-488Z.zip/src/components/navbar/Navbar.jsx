import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { MessageSquare, ShoppingBag, Award, Shield, ArrowRightLeft } from 'lucide-react';

export default function Navbar() {
  const location = useLocation();
  
  const links = [
    { name: 'Chat', path: 'Home', icon: MessageSquare },
    { name: 'Shop', path: 'Shop', icon: ShoppingBag },
    { name: 'Trade', path: 'Trade', icon: ArrowRightLeft },
    { name: 'Claiming', path: 'Claiming', icon: Award },
    { name: 'Admin', path: 'Admin', icon: Shield },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-slate-900/95 backdrop-blur-xl border-t border-slate-800 md:top-0 md:bottom-auto md:border-t-0 md:border-b z-50">
      <div className="max-w-7xl mx-auto px-4">
        <div className="flex items-center justify-around md:justify-center md:gap-8 h-16">
          {links.map((link) => {
            const Icon = link.icon;
            const isActive = location.pathname.includes(link.path);
            return (
              <Link
                key={link.path}
                to={createPageUrl(link.path)}
                className={`flex flex-col md:flex-row items-center gap-1 md:gap-2 px-3 py-2 rounded-lg transition-colors ${
                  isActive
                    ? 'text-blue-400 bg-blue-500/10'
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-xs md:text-sm font-medium">{link.name}</span>
              </Link>
            );
          })}
        </div>
      </div>
    </nav>
  );
}