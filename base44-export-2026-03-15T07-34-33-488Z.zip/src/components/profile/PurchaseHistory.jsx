const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React from 'react';
import { useQuery } from '@tanstack/react-query';

import { Badge } from '@/components/ui/badge';
import { Loader2, ShoppingBag } from 'lucide-react';
import { format } from 'date-fns';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function PurchaseHistory({ currentUser }) {
  const { data: purchases = [], isLoading } = useQuery({
    queryKey: ['purchaseHistory', currentUser?.email],
    queryFn: () => db.entities.NFTInventory.filter({ owner_email: currentUser.email }, '-purchase_date'),
    enabled: !!currentUser,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-16">
        <Loader2 className="w-5 h-5 animate-spin text-blue-500" />
      </div>
    );
  }

  if (purchases.length === 0) {
    return (
      <div className="text-center py-16 text-slate-500">
        <ShoppingBag className="w-10 h-10 mx-auto mb-3 opacity-30" />
        <p>No purchases yet</p>
        <Link to={createPageUrl('Shop')} className="text-blue-400 hover:underline text-sm mt-2 inline-block">
          Visit the Shop
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {purchases.map((item) => (
        <div
          key={item.id}
          className="flex items-center gap-4 bg-slate-900 rounded-xl border border-slate-800 p-4 hover:border-slate-700 transition-colors"
        >
          {/* Image */}
          <div className="w-14 h-14 rounded-lg bg-gradient-to-br from-blue-900/30 to-purple-900/30 flex-shrink-0 overflow-hidden flex items-center justify-center">
            {item.nft_image ? (
              <img src={item.nft_image} alt={item.nft_name} className="w-full h-full object-contain p-1" />
            ) : (
              <span className="text-2xl">🎨</span>
            )}
          </div>

          {/* Info */}
          <div className="flex-1 min-w-0">
            <p className="font-semibold truncate">{item.nft_name}</p>
            <p className="text-xs text-cyan-400">{item.collection}</p>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <Badge className="bg-slate-800 text-slate-400 border-slate-700 text-[10px]">#{item.token_id}</Badge>
              {item.purchase_date && (
                <span className="text-[11px] text-slate-500">
                  {format(new Date(item.purchase_date), 'MMM d, yyyy')}
                </span>
              )}
            </div>
          </div>

          {/* Price */}
          {item.price_usd != null && (
            <div className="text-right flex-shrink-0">
              <p className="text-green-400 font-bold">${item.price_usd}</p>
              <p className="text-[10px] text-slate-500">paid</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}