const db = globalThis.__B44_DB__ || {
  auth: { isAuthenticated: async () => false, me: async () => null },
  entities: new Proxy({}, { get: () => ({ filter: async () => [], get: async () => null, create: async () => ({}), update: async () => ({}), delete: async () => ({}) }) }),
  integrations: { Core: { UploadFile: async () => ({ file_url: '' }) } }
};

import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import Avatar from '../chat/Avatar';
import { Search, UserPlus, Check, Clock, Users, Loader2, X } from 'lucide-react';
import { toast } from 'sonner';

export default function AddPeople({ currentUser, profile }) {
  const [searchQuery, setSearchQuery] = useState('');
  const queryClient = useQueryClient();

  const { data: allProfiles = [] } = useQuery({
    queryKey: ['allProfiles'],
    queryFn: () => db.entities.UserProfile.list(),
    enabled: !!currentUser,
  });

  const { data: sentRequests = [] } = useQuery({
    queryKey: ['sentRequests', currentUser?.email],
    queryFn: () => db.entities.FriendRequest.filter({ from_email: currentUser.email }),
    enabled: !!currentUser,
  });

  const { data: receivedRequests = [] } = useQuery({
    queryKey: ['receivedRequests', currentUser?.email],
    queryFn: () => db.entities.FriendRequest.filter({ to_email: currentUser.email }),
    enabled: !!currentUser,
  });

  const sendMutation = useMutation({
    mutationFn: (targetProfile) =>
      db.entities.FriendRequest.create({
        from_email: currentUser.email,
        to_email: targetProfile.email,
        from_display_name: profile?.display_name || currentUser.full_name || currentUser.email,
        from_username: profile?.username || '',
        from_avatar: profile?.profile_picture || '',
        status: 'pending',
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['sentRequests'] });
      toast.success('Friend request sent!');
    },
    onError: () => toast.error('Failed to send request'),
  });

  const respondMutation = useMutation({
    mutationFn: ({ id, status }) => db.entities.FriendRequest.update(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['receivedRequests'] });
      toast.success('Request updated');
    },
  });

  const filteredProfiles = searchQuery.trim()
    ? allProfiles.filter(
        (p) =>
          p.email !== currentUser.email &&
          (p.username?.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.display_name?.toLowerCase().includes(searchQuery.toLowerCase()))
      )
    : [];

  const getStatus = (targetEmail) => {
    const sent = sentRequests.find((r) => r.to_email === targetEmail);
    if (sent) return sent.status === 'accepted' ? 'friends' : 'sent';
    const received = receivedRequests.find((r) => r.from_email === targetEmail && r.status === 'accepted');
    if (received) return 'friends';
    return null;
  };

  const pendingReceived = receivedRequests.filter((r) => r.status === 'pending');

  return (
    <div className="space-y-6">
      {/* Incoming requests */}
      {pendingReceived.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-slate-400 mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4" /> Pending Requests ({pendingReceived.length})
          </h3>
          <div className="space-y-3">
            {pendingReceived.map((req) => (
              <div key={req.id} className="flex items-center gap-3 bg-slate-900 rounded-xl border border-slate-800 p-3">
                <Avatar src={req.from_avatar} name={req.from_display_name || req.from_email} size="sm" />
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm truncate">{req.from_display_name || req.from_email}</p>
                  {req.from_username && <p className="text-xs text-slate-500">@{req.from_username}</p>}
                </div>
                <div className="flex gap-2">
                  <Button
                    size="sm"
                    className="bg-blue-600 hover:bg-blue-500 h-8 px-3"
                    onClick={() => respondMutation.mutate({ id: req.id, status: 'accepted' })}
                  >
                    <Check className="w-3 h-3 mr-1" /> Accept
                  </Button>
                  <Button
                    size="sm"
                    variant="ghost"
                    className="h-8 px-2 text-slate-400 hover:text-red-400"
                    onClick={() => respondMutation.mutate({ id: req.id, status: 'declined' })}
                  >
                    <X className="w-3 h-3" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Search */}
      <div>
        <h3 className="text-sm font-semibold text-slate-400 mb-3 flex items-center gap-2">
          <Users className="w-4 h-4" /> Find People
        </h3>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <Input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by username or name..."
            className="pl-10 bg-slate-900 border-slate-800"
          />
        </div>

        {searchQuery.trim() && (
          <div className="mt-3 space-y-2">
            {filteredProfiles.length === 0 ? (
              <p className="text-sm text-slate-500 text-center py-6">No users found</p>
            ) : (
              filteredProfiles.map((p) => {
                const status = getStatus(p.email);
                return (
                  <div key={p.id} className="flex items-center gap-3 bg-slate-900 rounded-xl border border-slate-800 p-3">
                    <Avatar src={p.profile_picture} name={p.display_name || p.email} size="sm" />
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm truncate">{p.display_name || p.email}</p>
                      {p.username && <p className="text-xs text-slate-500">@{p.username}</p>}
                    </div>
                    {status === 'friends' && (
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30">Friends</Badge>
                    )}
                    {status === 'sent' && (
                      <Badge className="bg-slate-700 text-slate-400 border-slate-600">Requested</Badge>
                    )}
                    {!status && (
                      <Button
                        size="sm"
                        className="bg-blue-600 hover:bg-blue-500 h-8"
                        onClick={() => sendMutation.mutate(p)}
                        disabled={sendMutation.isPending}
                      >
                        {sendMutation.isPending ? (
                          <Loader2 className="w-3 h-3 animate-spin" />
                        ) : (
                          <>
                            <UserPlus className="w-3 h-3 mr-1" /> Add
                          </>
                        )}
                      </Button>
                    )}
                  </div>
                );
              })
            )}
          </div>
        )}
      </div>
    </div>
  );
}